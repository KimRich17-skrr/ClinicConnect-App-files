<?php require __DIR__ . '/src/layout.php'; cc_page_start('reset.title'); ?>
<main class="narrow">
  <div class="card">
    <h1 data-i18n="reset.title"></h1>
    <form id="f">
      <label for="p1" data-i18n="reset.new"></label>
      <input id="p1" type="password" required minlength="8" autocomplete="new-password">
      <label for="p2" data-i18n="reset.confirm"></label>
      <input id="p2" type="password" required autocomplete="new-password">
      <button data-i18n="reset.submit"></button>
    </form>
    <p><a href="login.php" data-i18n="forgot.back"></a></p>
    <div id="out" class="msg" hidden role="status"></div>
  </div>
</main>
<?php cc_page_end(['reset']); ?>
