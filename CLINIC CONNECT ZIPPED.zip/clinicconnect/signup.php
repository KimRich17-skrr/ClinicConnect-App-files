<?php require __DIR__ . '/src/layout.php'; cc_page_start('signup.title'); ?>
<main class="narrow">
  <div class="card">
    <h1 data-i18n="signup.title"></h1>
    <form id="f">
      <label for="name" data-i18n="field.name"></label>
      <input id="name" required maxlength="80" autocomplete="name">
      <label for="email" data-i18n="field.email"></label>
      <input id="email" type="email" required autocomplete="email">
      <label for="password" data-i18n="field.password_hint"></label>
      <input id="password" type="password" required minlength="8" autocomplete="new-password">
      <label for="role" data-i18n="field.role"></label>
      <select id="role">
        <option value="patient" data-i18n="role.patient"></option>
        <option value="doctor" data-i18n="role.doctor"></option>
      </select>
      <div id="docf" hidden>
        <label for="dtype" data-i18n="field.doctorType"></label>
        <select id="dtype">
          <option value="general" data-i18n="role.general"></option>
          <option value="specialist" data-i18n="role.specialist"></option>
        </select>
        <div id="specw" hidden>
          <label for="spec" data-i18n="field.specialty"></label>
          <input id="spec" maxlength="60">
        </div>
        <label for="lic" data-i18n="field.license"></label>
        <input id="lic" maxlength="40">
      </div>
      <button data-i18n="signup.submit"></button>
    </form>
    <p><span data-i18n="signup.have"></span> <a href="login.php" data-i18n="login.title"></a></p>
    <div id="out" class="msg" hidden role="status"></div>
  </div>
</main>
<?php cc_page_end(['signup']); ?>
