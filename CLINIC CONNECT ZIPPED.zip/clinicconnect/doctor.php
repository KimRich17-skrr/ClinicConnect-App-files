<?php require __DIR__ . '/src/layout.php'; cc_page_start('nav.dashboard', ['dashboard']); ?>
<main class="grid">
  <section>
    <div class="card">
      <div id="lt" class="tabs"></div>
      <h2 id="qt"></h2>
      <p id="qh" class="muted small"></p>
      <div id="list"></div>
    </div>
  </section>
  <section class="card" id="view" hidden></section>
</main>
<?php cc_page_end(['caseview', 'doctor']); ?>
