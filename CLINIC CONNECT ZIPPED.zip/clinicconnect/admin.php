<?php require __DIR__ . '/src/layout.php'; cc_page_start('a.title', ['dashboard']); ?>
<main>
  <div class="card">
    <h2 data-i18n="a.title"></h2>
    <p class="muted" data-i18n="a.help"></p>
    <div id="out" class="msg" hidden role="status"></div>
    <div id="docs" class="table-wrap"></div>
  </div>
</main>
<?php cc_page_end(['admin']); ?>
