# ClinicConnect

Patients describe a problem by text or voice. A general doctor takes the case and can refer it,
with the patient's consent, to a specialist. English and Luganda (draft).

See `HOSTING.md` to put it online for free.

## Who can see what
Each case has three private conversations: patient+general doctor, general doctor+specialist,
patient+specialist. A message leaves its conversation only by an explicit, logged share, or inside a
referral the patient approved. Before a doctor takes a case, doctors see only topic, urgency,
age group, sex and language. A specialist sees a case code, not a name, until the patient allows it.
Administrators approve doctors but cannot read cases. The patient can see who opened their case.
Messages, transcripts, referral summaries and audio files are encrypted with `app_key`.

The app controls what it shows. It cannot stop a doctor from copying what they have legitimately seen.

## Settings (environment variables or `config.local.php`)
| Key | Meaning |
| --- | --- |
| `DB_HOST` `DB_NAME` `DB_USER` `DB_PASS` or `DB_DSN` | MySQL / MariaDB connection |
| `APP_KEY` | 32 random bytes, base64. Encrypts data. `setup.php` generates one. Back it up. |
| `SETUP_KEY` | Unlocks `setup.php` once |
| `AUTO_VERIFY_EMAIL` | `1` (default): accounts need no email check. Set `0` when email works |
| `MAIL_ENABLED`, `MAIL_FROM` | Email sending through PHP `mail()` |
| `ASR_PROVIDER` | `none` (default) or `sunbird` |
| `ASR_TOKEN`, `ASR_URL` | Sunbird AI token and endpoint. Request format follows their docs but is untested |
| `AUDIO_MAX_BYTES`, `AUDIO_MAX_SECONDS` | Voice limits (3 MB, 180 s) |
| `TRUST_PROXY` | Read the visitor IP from proxy headers (default on) |

## Files
- `api.php` all server routes; `src/` classes (`CaseService.php` holds the access rules)
- `lang/en.json`, `lang/lg.json` every word shown to people; add a language by adding a file and listing it in `Validator::LANGS` and the picker in `src/layout.php`
- `schema.sql` database tables
- `assets/js/caseview.js` the case screen; `api.js` shared helpers and the voice recorder
