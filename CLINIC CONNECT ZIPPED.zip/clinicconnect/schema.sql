-- ClinicConnect schema (fresh install).
-- Create an empty database first (your host's control panel does this),
-- then either run setup.php (recommended) or import this file in phpMyAdmin.

CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(80)  NOT NULL,
  email         VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('patient','doctor','admin') NOT NULL,
  doctor_type   ENUM('general','specialist') NULL,
  specialty     VARCHAR(60)  NULL,
  license_no    VARCHAR(40)  NULL,
  approved      TINYINT(1)   NOT NULL DEFAULT 1,
  verified      TINYINT(1)   NOT NULL DEFAULT 0,
  lang          VARCHAR(5)   NOT NULL DEFAULT 'en',
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tokens (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  type       ENUM('verify','reset') NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  INDEX (token_hash),
  INDEX (user_id, type),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  k            VARCHAR(190) PRIMARY KEY,
  hits         INT NOT NULL DEFAULT 0,
  window_start DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A case. `subject` and the patient's identity are only visible to the patient
-- and the general doctor who claimed it. Others see `code`, category, age band, sex.
CREATE TABLE IF NOT EXISTS cases (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  patient_id    INT NOT NULL,
  code          CHAR(8) NOT NULL UNIQUE,
  category      VARCHAR(30) NOT NULL,
  urgency       ENUM('routine','soon','urgent') NOT NULL DEFAULT 'routine',
  lang          VARCHAR(5) NOT NULL DEFAULT 'en',
  age_band      VARCHAR(10) NULL,
  sex           ENUM('f','m','x') NULL,
  subject       VARCHAR(120) NOT NULL DEFAULT '',
  status        ENUM('new','with_general','with_specialist','closed') NOT NULL DEFAULT 'new',
  general_id    INT NULL,
  specialist_id INT NULL,
  name_shared   TINYINT(1) NOT NULL DEFAULT 0,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (patient_id),
  INDEX (general_id),
  INDEX (specialist_id),
  INDEX (status, urgency),
  FOREIGN KEY (patient_id)    REFERENCES users(id),
  FOREIGN KEY (general_id)    REFERENCES users(id),
  FOREIGN KEY (specialist_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Three private conversations per case:
--   pg = patient + general doctor
--   gs = general doctor + specialist (consult; patient does not see it)
--   ps = patient + specialist        (general doctor does not see it)
CREATE TABLE IF NOT EXISTS threads (
  id      INT AUTO_INCREMENT PRIMARY KEY,
  case_id INT NOT NULL,
  type    ENUM('pg','gs','ps') NOT NULL,
  UNIQUE KEY case_type (case_id, type),
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- `body` is encrypted (base64 of nonce+ciphertext).
CREATE TABLE IF NOT EXISTS messages (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  thread_id  INT NOT NULL,
  sender_id  INT NULL,
  is_system  TINYINT(1) NOT NULL DEFAULT 0,
  body       MEDIUMTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (thread_id),
  FOREIGN KEY (thread_id) REFERENCES threads(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The audio file itself is encrypted on disk (storage/audio). `transcript` is encrypted.
CREATE TABLE IF NOT EXISTS audio_clips (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  message_id        INT NOT NULL UNIQUE,
  file              VARCHAR(64) NOT NULL,
  mime              VARCHAR(40) NOT NULL,
  bytes             INT NOT NULL,
  seconds           SMALLINT NOT NULL DEFAULT 0,
  transcript        MEDIUMTEXT NULL,
  transcript_status ENUM('none','done','failed') NOT NULL DEFAULT 'none',
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Explicit sharing of one message with one person who is not in its thread.
CREATE TABLE IF NOT EXISTS message_shares (
  message_id   INT NOT NULL,
  with_user_id INT NOT NULL,
  shared_by    INT NOT NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (message_id, with_user_id),
  FOREIGN KEY (message_id)   REFERENCES messages(id) ON DELETE CASCADE,
  FOREIGN KEY (with_user_id) REFERENCES users(id),
  FOREIGN KEY (shared_by)    REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- General doctor -> specialist. The patient must consent before the specialist
-- sees anything. `summary` is encrypted.
CREATE TABLE IF NOT EXISTS referrals (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  case_id       INT NOT NULL,
  general_id    INT NOT NULL,
  specialist_id INT NOT NULL,
  summary       MEDIUMTEXT NOT NULL,
  include_name  TINYINT(1) NOT NULL DEFAULT 0,
  status        ENUM('awaiting_consent','pending','accepted',
                     'declined_patient','declined_specialist','withdrawn')
                NOT NULL DEFAULT 'awaiting_consent',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (case_id),
  INDEX (specialist_id, status),
  FOREIGN KEY (case_id)       REFERENCES cases(id) ON DELETE CASCADE,
  FOREIGN KEY (general_id)    REFERENCES users(id),
  FOREIGN KEY (specialist_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS referral_items (
  referral_id INT NOT NULL,
  message_id  INT NOT NULL,
  PRIMARY KEY (referral_id, message_id),
  FOREIGN KEY (referral_id) REFERENCES referrals(id) ON DELETE CASCADE,
  FOREIGN KEY (message_id)  REFERENCES messages(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_log (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NULL,
  case_id    INT NULL,
  action     VARCHAR(40) NOT NULL,
  detail     VARCHAR(255) NOT NULL DEFAULT '',
  ip         VARCHAR(45) NOT NULL DEFAULT '',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (case_id, created_at),
  INDEX (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
