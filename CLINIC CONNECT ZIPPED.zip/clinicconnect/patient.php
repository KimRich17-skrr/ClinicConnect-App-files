<?php require __DIR__ . '/src/layout.php'; cc_page_start('nav.dashboard', ['dashboard']); ?>
<main class="grid">
  <section>
    <div class="card">
      <h2 data-i18n="p.new.title"></h2>
      <form id="nf">
        <label for="cat" data-i18n="p.category"></label>
        <select id="cat" required></select>

        <label data-i18n="p.urgency"></label>
        <div id="urg" class="radios"></div>

        <div class="two">
          <div><label for="age" data-i18n="p.age"></label><select id="age"></select></div>
          <div><label for="sex" data-i18n="p.sex"></label><select id="sex"></select></div>
        </div>

        <label for="sub" data-i18n="p.subject"></label>
        <input id="sub" maxlength="120">

        <label for="txt" data-i18n="p.details"></label>
        <textarea id="txt" rows="5" maxlength="2000"></textarea>

        <div id="rec"></div>

        <button data-i18n="p.send"></button>
      </form>
      <p class="muted small" data-i18n="p.privacy"></p>
      <p class="muted small" data-i18n="p.not_emergency"></p>
      <div id="nout" class="msg" hidden role="status"></div>
    </div>

    <div class="card">
      <h2 data-i18n="p.mycases"></h2>
      <div id="list"></div>
    </div>
  </section>

  <section class="card" id="view" hidden></section>
</main>
<?php cc_page_end(['caseview', 'patient']); ?>
