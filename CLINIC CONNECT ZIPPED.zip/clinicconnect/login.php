<?php require __DIR__ . '/src/layout.php'; cc_page_start('login.title'); ?>
<main class="narrow">
  <div class="card">
    <h1 data-i18n="login.title"></h1>
    <form id="f">
      <label for="email" data-i18n="field.email"></label>
      <input id="email" type="email" required autocomplete="email">
      <label for="password" data-i18n="field.password"></label>
      <input id="password" type="password" required autocomplete="current-password">
      <button data-i18n="login.submit"></button>
    </form>
    <button id="resend" class="alt" hidden data-i18n="login.resend"></button>
    <p><a href="forgot.php" data-i18n="login.forgot"></a> &middot; <a href="signup.php" data-i18n="login.create"></a></p>
    <div id="out" class="msg" hidden role="status"></div>
  </div>
</main>
<?php cc_page_end(['login']); ?>
