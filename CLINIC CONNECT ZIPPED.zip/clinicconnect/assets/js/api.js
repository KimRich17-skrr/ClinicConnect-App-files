/* ClinicConnect shared helpers: API calls, translations, DOM helpers, voice recorder. */

const qs = (sel, root = document) => root.querySelector(sel);

/* ---------------- DOM helper (always uses textContent, never innerHTML) ---------------- */
function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
        if (v === false || v === null || v === undefined) continue;
        if (k === "class") el.className = v;
        else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
        else el.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) {
        if (kid === null || kid === undefined || kid === false) continue;
        el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
}

/* ---------------- Translations ---------------- */
const SUPPORTED_LANGS = ["en", "lg"];
let LANG = "en";
let STR = {};
let STR_EN = {};

function store(key, value) {
    try {
        if (value === undefined) return localStorage.getItem(key);
        localStorage.setItem(key, value);
    } catch {
        return null;
    }
    return null;
}

function t(key, params) {
    let s = STR[key] ?? STR_EN[key] ?? key;
    if (params) {
        for (const [k, v] of Object.entries(params)) {
            s = s.split("{" + k + "}").join(String(v));
        }
    }
    return s;
}

async function loadJson(path) {
    const res = await fetch(path, { cache: "no-cache" });
    if (!res.ok) throw new Error("lang");
    return res.json();
}

function applyI18n(root = document) {
    root.querySelectorAll("[data-i18n]").forEach((el) => {
        el.textContent = t(el.dataset.i18n);
    });
    root.querySelectorAll("[data-i18n-ph]").forEach((el) => {
        el.setAttribute("placeholder", t(el.dataset.i18nPh));
    });
    const titleKey = document.body.dataset.title;
    if (titleKey) document.title = t(titleKey) + " - ClinicConnect";
    document.documentElement.lang = LANG;
}

async function initI18n() {
    const saved = store("cc_lang");
    LANG = SUPPORTED_LANGS.includes(saved) ? saved : "en";
    try {
        STR_EN = await loadJson("lang/en.json");
        STR = LANG === "en" ? STR_EN : await loadJson(`lang/${LANG}.json`);
    } catch {
        /* keys show instead of text if language files fail to load */
    }
    applyI18n();

    const sel = qs("#lang");
    if (sel) {
        sel.value = LANG;
        sel.addEventListener("change", async () => {
            store("cc_lang", sel.value);
            try {
                await api("/lang", "POST", { lang: sel.value });
            } catch {
                /* not logged in: fine */
            }
            location.reload();
        });
    }
    const draft = qs("#draft");
    if (draft) {
        draft.hidden = LANG === "en";
        draft.textContent = t("lang.draft");
    }
}

const i18nReady = initI18n();

function fmtTime(ts) {
    return new Date(ts).toLocaleString(LANG === "lg" ? "en-GB" : undefined);
}

/* ---------------- API ---------------- */
async function api(path, method = "GET", body) {
    const url = "api.php?r=" + encodeURIComponent(path);
    const options = {
        method,
        credentials: "same-origin",
        headers: { "X-Requested-With": "cc" },
    };
    if (method === "POST" && body === undefined) body = {};
    if (body instanceof FormData) {
        options.body = body; // browser sets the multipart boundary
    } else if (body !== undefined) {
        options.headers["Content-Type"] = "application/json";
        options.body = JSON.stringify(body);
    }

    let res;
    try {
        res = await fetch(url, options);
    } catch {
        const e = new Error("network");
        e.code = "network";
        throw e;
    }

    let data = {};
    try {
        data = await res.json();
    } catch {
        /* non-JSON error response */
    }

    if (!res.ok) {
        const err = new Error(data.code || "generic");
        err.code = data.code || "generic";
        err.status = res.status;
        throw err;
    }
    return data;
}

function errText(err) {
    const key = "err." + (err && err.code ? err.code : "generic");
    return STR[key] || STR_EN[key] ? t(key) : t("err.generic");
}

/** Show a status message in a `.msg` element. */
function msg(el, text, ok = false) {
    el.textContent = text;
    el.className = "msg " + (ok ? "ok" : "err");
    el.hidden = false;
}
const showErr = (el, err) => msg(el, errText(err));

let FEATURES = { asr: false };

async function requireRole(role) {
    await i18nReady;
    try {
        const { user, features } = await api("/me");
        FEATURES = features || FEATURES;
        if (user.role !== role) {
            location.replace("login.php");
            return null;
        }
        return user;
    } catch {
        location.replace("login.php");
        return null;
    }
}

async function logout() {
    try {
        await api("/logout", "POST");
    } catch {
        /* ignore */
    }
    location.replace("login.php");
}

function homeFor(role) {
    return role === "patient" ? "patient.php" : role === "admin" ? "admin.php" : "doctor.php";
}

function onSubmit(selector, handler) {
    const form = qs(selector);
    if (form) {
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            handler(e);
        });
    }
}

function onClick(selector, handler) {
    const el = qs(selector);
    if (el) el.addEventListener("click", handler);
}

/* ---------------- Voice recorder ---------------- */
const MAX_REC_SECONDS = 180;

/**
 * Adds a record button to `host`. Returns { blob(), seconds(), reset() }.
 * Works in Chrome/Android (WebM) and Safari/iPhone (MP4); needs HTTPS.
 */
function createRecorder(host) {
    const state = { blob: null, seconds: 0, rec: null, stream: null, timer: null, chunks: [] };
    const supported = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);

    const status = h("span", { class: "rec-status", role: "status" });
    const preview = h("audio", { controls: true, hidden: true });
    const startBtn = h("button", { type: "button", class: "alt rec-btn" }, t("rec.start"));
    const stopBtn = h("button", { type: "button", class: "rec-btn danger", hidden: true }, t("rec.stop"));
    const dropBtn = h("button", { type: "button", class: "alt rec-btn", hidden: true }, t("rec.discard"));
    const hint = h("p", { class: "muted small" }, supported ? t("rec.hint") : t("rec.unsupported"));

    host.append(h("div", { class: "rec" }, h("div", { class: "rec-row" }, startBtn, stopBtn, dropBtn, status), preview, hint));
    if (!supported) startBtn.disabled = true;

    function pickMime() {
        const list = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus"];
        return list.find((m) => MediaRecorder.isTypeSupported(m)) || "";
    }

    function cleanup() {
        clearInterval(state.timer);
        if (state.stream) state.stream.getTracks().forEach((tr) => tr.stop());
        state.stream = null;
    }

    function reset() {
        cleanup();
        if (state.rec && state.rec.state !== "inactive") {
            state.rec.onstop = null;
            state.rec.stop();
        }
        state.blob = null;
        state.seconds = 0;
        preview.hidden = true;
        preview.removeAttribute("src");
        startBtn.hidden = false;
        stopBtn.hidden = true;
        dropBtn.hidden = true;
        status.textContent = "";
    }

    startBtn.addEventListener("click", async () => {
        try {
            state.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        } catch {
            status.textContent = t("rec.denied");
            return;
        }
        const mime = pickMime();
        state.chunks = [];
        state.rec = new MediaRecorder(state.stream, mime ? { mimeType: mime } : undefined);
        state.rec.ondataavailable = (e) => e.data.size && state.chunks.push(e.data);
        state.rec.onstop = () => {
            cleanup();
            state.blob = new Blob(state.chunks, { type: state.rec.mimeType || mime || "audio/webm" });
            preview.src = URL.createObjectURL(state.blob);
            preview.hidden = false;
            stopBtn.hidden = true;
            dropBtn.hidden = false;
            status.textContent = t("rec.ready");
        };
        state.seconds = 0;
        state.rec.start();
        startBtn.hidden = true;
        stopBtn.hidden = false;
        status.textContent = t("rec.recording") + " 0:00";
        state.timer = setInterval(() => {
            state.seconds += 1;
            const m = Math.floor(state.seconds / 60);
            const s = String(state.seconds % 60).padStart(2, "0");
            status.textContent = `${t("rec.recording")} ${m}:${s}`;
            if (state.seconds >= MAX_REC_SECONDS) stopBtn.click();
        }, 1000);
    });

    stopBtn.addEventListener("click", () => {
        if (state.rec && state.rec.state !== "inactive") state.rec.stop();
    });
    dropBtn.addEventListener("click", reset);

    return {
        blob: () => state.blob,
        seconds: () => state.seconds,
        reset,
    };
}

/** Append recorded audio (if any) to a FormData. */
function attachRecording(fd, recorder) {
    const blob = recorder.blob();
    if (!blob) return;
    const ext = blob.type.includes("mp4") ? "m4a" : blob.type.includes("ogg") ? "ogg" : "webm";
    fd.append("audio", blob, "voice." + ext);
    fd.append("seconds", String(recorder.seconds()));
}
