const token = new URLSearchParams(location.search).get("token") || "";

i18nReady.then(() =>
    api("/verify?token=" + encodeURIComponent(token))
        .then(() => {
            qs("#t").textContent = "";
            msg(qs("#out"), t("verify.ok"), true);
        })
        .catch((err) => {
            qs("#t").textContent = "";
            showErr(qs("#out"), err);
        }),
);
