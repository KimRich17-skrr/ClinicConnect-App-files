(async () => {
    const me = await requireRole("admin");
    if (!me) return;
    qs("#nav").replaceChildren(h("span", null, me.name), h("button", { class: "alt", onclick: logout }, t("nav.logout")), qs("#lang"));
    await load();
})();

async function act(id, what) {
    try {
        await api(`/admin/doctors/${id}/${what}`, "POST");
        await load();
    } catch (err) {
        showErr(qs("#out"), err);
    }
}

async function load() {
    const { doctors } = await api("/admin/doctors");
    const box = qs("#docs");
    box.replaceChildren();
    if (!doctors.length) return box.append(h("p", { class: "muted" }, t("a.empty")));

    const rows = doctors.map((d) =>
        h("tr", null,
            h("td", null, d.name, h("br"), h("small", { class: "muted" }, d.email)),
            h("td", null, d.doctorType === "specialist" ? `${t("role.specialist")}: ${d.specialty}` : t("role.general")),
            h("td", null, d.licenseNo || ""),
            h("td", null, t(d.approved ? "a.approved" : "a.waiting")),
            h("td", null,
                d.approved
                    ? h("button", { class: "alt small-btn", onclick: () => act(d.id, "suspend") }, t("a.suspend"))
                    : [
                          h("button", { class: "small-btn", onclick: () => act(d.id, "approve") }, t("a.approve")),
                          " ",
                          h("button", { class: "alt small-btn", onclick: () => act(d.id, "reject") }, t("a.reject")),
                      ]),
        ),
    );
    box.append(
        h("table", null,
            h("thead", null, h("tr", null, ["a.col.name", "a.col.type", "a.col.license", "a.col.status", ""].map((k) => h("th", null, k ? t(k) : "")))),
            h("tbody", null, rows)),
    );
}
