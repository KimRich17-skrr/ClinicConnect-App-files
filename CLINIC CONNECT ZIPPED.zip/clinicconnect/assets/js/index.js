i18nReady.then(() => {
    api("/me")
        .then(({ user }) => {
            const nav = qs("#nav");
            const link = h("a", { href: homeFor(user.role) }, t("nav.dashboard"));
            nav.replaceChildren(link, qs("#lang"));
        })
        .catch(() => {
            /* not logged in: keep the default links */
        });
});
