let me = null;
let currentId = null;
let mode = "mine"; // "pool" or "mine"

(async () => {
    me = await requireRole("doctor");
    if (!me) return;
    qs("#nav").replaceChildren(
        h("span", null, `${me.name} (${me.specialty})`),
        h("button", { id: "logout", class: "alt", onclick: logout }, t("nav.logout")),
        qs("#lang"),
    );

    if (me.doctorType === "general") {
        const bar = qs("#lt");
        bar.append(
            h("button", { class: "tab", "data-m": "pool", onclick: () => setMode("pool") }, t("d.tab.pool")),
            h("button", { class: "tab", "data-m": "mine", onclick: () => setMode("mine") }, t("d.tab.mine")),
        );
        mode = "pool";
    } else {
        qs("#lt").hidden = true;
    }
    await setMode(mode);
})();

async function setMode(m) {
    mode = m;
    qs("#lt").querySelectorAll("button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.m === m)));
    if (me.doctorType === "general") {
        qs("#qt").textContent = m === "pool" ? t("d.pool.title") : t("d.tab.mine");
        qs("#qh").textContent = m === "pool" ? t("d.pool.help") : "";
    } else {
        qs("#qt").textContent = t("d.spec.title");
        qs("#qh").textContent = "";
    }
    await loadList();
}

async function loadList() {
    const list = qs("#list");
    list.replaceChildren();

    if (mode === "pool") {
        const { pool } = await api("/pool");
        if (!pool.length) return list.append(h("p", { class: "muted" }, t("d.pool.empty")));
        for (const c of pool) {
            const bits = [t("cat." + c.category), t("urg." + c.urgency)];
            if (c.ageBand) bits.push(c.ageBand);
            if (c.sex) bits.push(t("sex." + c.sex));
            bits.push(c.lang === "lg" ? "Oluganda" : "English");
            list.append(
                h("div", { class: "item pool urg-" + c.urgency },
                    h("span", null, `${c.code} - ${bits.join(" | ")}`),
                    h("button", { class: "small-btn", onclick: () => claim(c.id) }, t("act.claim"))),
            );
        }
        return;
    }

    const { cases } = await api("/cases");
    if (!cases.length) return list.append(h("p", { class: "muted" }, t("d.mine.empty")));
    for (const c of cases) {
        const who = c.patientName || t("msg.unknown_patient", { code: c.code });
        const label = `${who}: ${c.subject || t("cat." + c.category)} - ${t("status." + c.status)}`;
        list.append(
            h("button", { class: "item" + (c.id === currentId ? " active" : ""), onclick: () => openCase(c.id) },
                label,
                c.flag && c.rel === "referee" ? h("span", { class: "badge" }, t("d.referral_waiting")) : null),
        );
    }
}

async function claim(id) {
    try {
        const { case: c } = await api(`/cases/${id}/claim`, "POST");
        mode = "mine";
        await setMode("mine");
        await showCase(c);
    } catch (err) {
        alert(errText(err));
        loadList();
    }
}

async function openCase(id) {
    try {
        const { case: c } = await api("/cases/" + id);
        await showCase(c);
        loadList();
    } catch (err) {
        alert(errText(err));
    }
}

async function showCase(c) {
    currentId = c.id;
    const view = qs("#view");
    view.hidden = false;
    await caseUI.render(view, c, me, async (nc) => {
        await showCase(nc);
        loadList();
    });
}
