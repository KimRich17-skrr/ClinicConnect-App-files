const token = new URLSearchParams(location.search).get("token") || "";

onSubmit("#f", async () => {
    await i18nReady;
    const p1 = qs("#p1").value;
    if (p1 !== qs("#p2").value) return msg(qs("#out"), t("reset.mismatch"));
    try {
        await api("/reset", "POST", { token, password: p1 });
        msg(qs("#out"), t("reset.done"), true);
        setTimeout(() => (location.href = "login.php"), 2000);
    } catch (err) {
        showErr(qs("#out"), err);
    }
});
