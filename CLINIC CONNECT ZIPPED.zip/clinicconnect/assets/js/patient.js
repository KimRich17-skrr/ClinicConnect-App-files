let me = null;
let rec = null;
let currentId = null;

(async () => {
    me = await requireRole("patient");
    if (!me) return;
    qs("#nav").replaceChildren(h("span", null, me.name), h("button", { id: "logout", class: "alt", onclick: logout }, t("nav.logout")), qs("#lang"));

    // Form options
    const cat = qs("#cat");
    cat.append(h("option", { value: "" }, "-"));
    ["general", "fever", "breathing", "stomach", "pain", "skin", "pregnancy", "child", "mental", "injury", "chronic", "other"]
        .forEach((k) => cat.append(h("option", { value: k }, t("cat." + k))));

    const urg = qs("#urg");
    ["routine", "soon", "urgent"].forEach((k, i) => {
        urg.append(h("label", { class: "pick" }, h("input", { type: "radio", name: "urgency", value: k, checked: i === 0 }), " ", t("urg." + k)));
    });

    const age = qs("#age");
    age.append(h("option", { value: "" }, "-"));
    ["0-4", "5-12", "13-17", "18-39", "40-59", "60+"].forEach((k) => age.append(h("option", { value: k }, k)));

    const sex = qs("#sex");
    sex.append(h("option", { value: "" }, "-"));
    ["f", "m", "x"].forEach((k) => sex.append(h("option", { value: k }, t("sex." + k))));

    rec = createRecorder(qs("#rec"));
    await loadCases();
})();

async function loadCases() {
    const { cases } = await api("/cases");
    const list = qs("#list");
    list.replaceChildren();
    if (!cases.length) {
        list.append(h("p", { class: "muted" }, t("p.nocases")));
        return;
    }
    for (const c of cases) {
        const label = `${c.subject || t("cat." + c.category)} - ${t("status." + c.status)}`;
        list.append(
            h("button", { class: "item" + (c.id === currentId ? " active" : ""), onclick: () => openCase(c.id) },
                label,
                c.flag ? h("span", { class: "badge" }, t("p.need_consent")) : null),
        );
    }
}

async function openCase(id) {
    currentId = id;
    try {
        const { case: c } = await api("/cases/" + id);
        await showCase(c);
        loadCases();
    } catch (err) {
        showErr(qs("#nout"), err);
    }
}

async function showCase(c) {
    currentId = c.id;
    const view = qs("#view");
    view.hidden = false;
    await caseUI.render(view, c, me, async (nc) => {
        await showCase(nc);
        loadCases();
    });
}

onSubmit("#nf", async () => {
    const fd = new FormData();
    fd.append("category", qs("#cat").value);
    fd.append("urgency", qs("#nf input[name=urgency]:checked").value);
    fd.append("ageBand", qs("#age").value);
    fd.append("sex", qs("#sex").value);
    fd.append("subject", qs("#sub").value);
    fd.append("text", qs("#txt").value);
    attachRecording(fd, rec);
    try {
        const { case: c } = await api("/cases", "POST", fd);
        qs("#nf").reset();
        rec.reset();
        qs("#nout").hidden = true;
        await showCase(c);
        loadCases();
        qs("#view").scrollIntoView({ behavior: "smooth" });
    } catch (err) {
        showErr(qs("#nout"), err);
    }
});
