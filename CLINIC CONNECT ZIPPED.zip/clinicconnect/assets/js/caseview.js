/* One case, shown for whoever is looking at it. The server decides what each person
   may see; this file only draws what it was given. */

const caseUI = (() => {
    const activeTab = {};

    const roleName = (r) => t("role." + r);
    const lower = (s) => s.toLowerCase();

    function sysText(m) {
        const p = {};
        for (const [k, v] of Object.entries(m.params || {})) {
            p[k] = k === "by" || k === "with" ? lower(roleName(v)) : v;
        }
        return t(m.key, p);
    }

    function senderLabel(m, c, me) {
        if (m.from === me.id) return t("msg.you");
        if (m.role === "patient") {
            return m.name || t("msg.unknown_patient", { code: c.code });
        }
        return `${m.name || ""} (${roleName(m.role)})`.trim();
    }

    async function loadAudio(clipId, holder) {
        holder.textContent = t("audio.loading");
        try {
            const res = await fetch("api.php?r=" + encodeURIComponent("/audio/" + clipId), {
                credentials: "same-origin",
            });
            if (!res.ok) throw new Error("audio");
            const blob = await res.blob();
            const el = h("audio", { controls: true, src: URL.createObjectURL(blob) });
            holder.replaceChildren(el);
            el.play().catch(() => {});
        } catch {
            holder.textContent = t("err.not_found");
        }
    }

    function audioBlock(m, ctx) {
        const a = m.audio;
        const holder = h("div", { class: "audio-holder" });
        const play = h(
            "button",
            { type: "button", class: "alt small-btn", onclick: () => loadAudio(a.id, holder) },
            `${t("audio.play")} (${Math.floor(a.seconds / 60)}:${String(a.seconds % 60).padStart(2, "0")})`,
        );
        holder.append(play);

        const box = h("div", { class: "audio" }, h("strong", { class: "small" }, t("audio.voice")), holder);

        if (a.status === "done" && a.transcript) {
            box.append(
                h("p", { class: "transcript" }, a.transcript),
                h("p", { class: "muted small" }, t("audio.machine")),
            );
        } else if (FEATURES.asr) {
            if (a.status === "failed") box.append(h("p", { class: "muted small" }, t("audio.failed")));
            box.append(
                h("button", {
                    type: "button",
                    class: "alt small-btn",
                    onclick: () => ctx.run(() => api(`/audio/${a.id}/transcribe`, "POST")),
                }, t("audio.transcribe")),
            );
        }
        return box;
    }

    function messageEl(m, c, me, ctx) {
        if (m.system) {
            return h("div", { class: "bubble sys" }, h("p", null, sysText(m)), h("small", { class: "muted" }, fmtTime(m.at)));
        }

        const bubble = h(
            "div",
            { class: "bubble " + (m.from === me.id ? "mine" : "") },
            h("strong", null, senderLabel(m, c, me)),
        );
        if (m.text) bubble.append(h("p", null, m.text));
        if (m.audio) bubble.append(audioBlock(m, ctx));
        bubble.append(h("small", { class: "muted" }, fmtTime(m.at)));

        // Sharing controls (only for members of the conversation)
        if (m.canShareWith || m.sharedWith) {
            const row = h("div", { class: "share-row" });
            for (const r of m.canShareWith || []) {
                row.append(
                    h("button", {
                        type: "button",
                        class: "alt small-btn",
                        onclick: () => ctx.run(() => api(`/cases/${c.id}/messages/${m.id}/share`, "POST", { with: r })),
                    }, `${t("msg.share")}: ${lower(roleName(r))}`),
                );
            }
            if ((m.sharedWith || []).length) {
                row.append(
                    h("span", { class: "muted small" }, t("msg.shared_with", { who: m.sharedWith.map((r) => lower(roleName(r))).join(", ") })),
                );
                for (const r of m.sharedByMe || []) {
                    row.append(
                        h("button", {
                            type: "button",
                            class: "alt small-btn",
                            onclick: () => ctx.run(() => api(`/cases/${c.id}/messages/${m.id}/unshare`, "POST", { with: r })),
                        }, `${t("msg.unshare")}: ${lower(roleName(r))}`),
                    );
                }
            }
            if (row.childNodes.length) bubble.append(row);
        }
        if (m.via) {
            bubble.append(h("small", { class: "tag" }, t(m.via === "referral" ? "shared.via_referral" : "shared.via_share")));
        }
        return bubble;
    }

    function threadPanel(type, msgs, c, me, ctx) {
        const relKey = c.rel === "referee" ? "specialist" : c.rel;
        const wrap = h("div", { class: "panel" });
        const note = t(`thread.${type}.${relKey}`);
        if (note !== `thread.${type}.${relKey}`) wrap.append(h("p", { class: "notice" }, note));

        const box = h("div", { class: "thread" });
        if (!msgs.length) box.append(h("p", { class: "muted" }, t("msg.empty")));
        msgs.forEach((m) => box.append(messageEl(m, c, me, ctx)));
        wrap.append(box);

        if (c.can.reply.includes(type)) {
            const ta = h("textarea", { rows: 3, "aria-label": t("msg.reply"), placeholder: t("msg.reply"), maxlength: 2000 });
            const recHost = h("div");
            const form = h("form", { class: "composer" }, ta, recHost, h("button", null, t("msg.send")));
            wrap.append(form);
            const rec = createRecorder(recHost);
            form.addEventListener("submit", (e) => {
                e.preventDefault();
                const fd = new FormData();
                fd.append("thread", type);
                fd.append("text", ta.value);
                attachRecording(fd, rec);
                ctx.run(() => api(`/cases/${c.id}/messages`, "POST", fd));
            });
            // keep scrolled to newest
            setTimeout(() => (box.scrollTop = box.scrollHeight), 0);
        }
        return wrap;
    }

    function sharedPanel(c, me, ctx) {
        const wrap = h("div", { class: "panel" });
        const box = h("div", { class: "thread" });
        if (!c.shared.length) box.append(h("p", { class: "muted" }, t("shared.empty")));
        c.shared.forEach((m) => box.append(messageEl(m, c, me, ctx)));
        wrap.append(box);
        return wrap;
    }

    // ---------- referral blocks ----------

    function referralBlock(c, me, ctx) {
        const r = c.referral;
        if (!r) return null;
        const box = h("div", { class: "card inner referral" });
        box.append(
            h("h3", null, t("ref.title")),
            h("p", null, h("strong", null, `${r.specialist || ""}${r.specialty ? " (" + r.specialty + ")" : ""}`)),
            h("p", { class: "tag-line" }, t("ref.status." + r.status)),
        );
        box.append(h("h4", null, t("ref.summary_label")), h("p", { class: "summary" }, r.summary));

        // list the messages that go with it
        const pool = c.rel === "patient" || c.rel === "general" ? c.threads.pg || [] : c.shared;
        const items = pool.filter((m) => r.itemIds.includes(m.id));
        if (items.length) {
            box.append(h("h4", null, t("ref.included")));
            const list = h("div", { class: "thread compact" });
            items.forEach((m) => list.append(messageEl({ ...m, canShareWith: null, sharedWith: null, via: null }, c, me, ctx)));
            box.append(list);
        }
        if (r.includeName) box.append(h("p", { class: "notice" }, t("ref.consent.name")));

        if (c.can.consent) {
            box.prepend(
                h("p", { class: "notice strong" }, t("ref.consent.body", { name: r.specialist || "", specialty: r.specialty || "" })),
            );
            box.append(
                h("div", { class: "btn-row" },
                    h("button", { type: "button", onclick: () => ctx.run(() => api(`/cases/${c.id}/referral/consent`, "POST", { allow: true })) }, t("ref.consent.allow")),
                    h("button", { type: "button", class: "alt", onclick: () => ctx.run(() => api(`/cases/${c.id}/referral/consent`, "POST", { allow: false })) }, t("ref.consent.deny")),
                ),
            );
        }
        if (c.can.respond) {
            box.prepend(h("p", { class: "notice strong" }, t("ref.respond.title")));
            box.append(
                h("div", { class: "btn-row" },
                    h("button", { type: "button", onclick: () => ctx.run(() => api(`/cases/${c.id}/referral/respond`, "POST", { accept: true })) }, t("ref.respond.accept")),
                    h("button", { type: "button", class: "alt", onclick: () => ctx.run(() => api(`/cases/${c.id}/referral/respond`, "POST", { accept: false })) }, t("ref.respond.decline")),
                ),
            );
        }
        if (c.can.withdraw) {
            box.append(h("button", { type: "button", class: "alt", onclick: () => ctx.run(() => api(`/cases/${c.id}/referral/withdraw`, "POST")) }, t("ref.withdraw")));
        }
        return box;
    }

    async function referralBuilder(c, me, ctx) {
        const box = h("details", { class: "card inner" }, h("summary", null, t("ref.title")));
        const sel = h("select", { id: "ref-spec" });
        let specialists = [];
        try {
            specialists = (await api("/specialists")).specialists;
        } catch {
            /* shown as empty */
        }
        if (!specialists.length) sel.append(h("option", { value: "" }, t("ref.none")));
        specialists.forEach((s) => sel.append(h("option", { value: s.id }, `${s.name} - ${s.specialty}`)));

        const summary = h("textarea", { rows: 4, maxlength: 1500, required: true });
        const picks = h("div", { class: "picks" });
        (c.threads.pg || []).filter((m) => !m.system).forEach((m) => {
            const cb = h("input", { type: "checkbox", value: m.id });
            const label = h("label", { class: "pick" }, cb, " ", `${senderLabel(m, c, me)}: ${(m.text || t("audio.voice")).slice(0, 80)}${m.audio ? " [" + t("audio.voice") + "]" : ""}`);
            picks.append(label);
        });
        const incName = h("input", { type: "checkbox" });
        const form = h("form", null,
            h("label", null, t("ref.specialist")), sel,
            h("label", null, t("ref.summary")), summary,
            h("p", { class: "muted small" }, t("ref.summary_help")),
            h("label", null, t("ref.pick")), picks,
            h("label", { class: "pick" }, incName, " ", t("ref.include_name")),
            h("button", null, t("ref.submit")),
        );
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            ctx.run(() => api(`/cases/${c.id}/referral`, "POST", {
                specialistId: Number(sel.value),
                summary: summary.value,
                includeName: incName.checked,
                messageIds: [...picks.querySelectorAll("input:checked")].map((x) => Number(x.value)),
            }));
        });
        box.append(form);
        return box;
    }

    async function accessLog(c, holder) {
        holder.replaceChildren(h("p", { class: "muted" }, t("loading")));
        try {
            const { log } = await api(`/cases/${c.id}/access-log`);
            const list = h("ul", { class: "log" });
            if (!log.length) list.append(h("li", { class: "muted" }, t("log.empty")));
            log.forEach((x) => {
                const who = `${x.name}${x.specialty ? " (" + x.specialty + ")" : ""}`;
                list.append(h("li", null, `${fmtTime(x.at)} - ${who} ${t("log." + x.action)}`));
            });
            holder.replaceChildren(h("h4", null, t("log.title")), list);
        } catch (err) {
            holder.replaceChildren(h("p", { class: "msg err" }, errText(err)));
        }
    }

    // ---------- the whole case ----------

    async function render(root, c, me, onUpdate) {
        const out = h("div", { class: "msg", hidden: true, role: "status" });
        const ctx = {
            async run(fn) {
                try {
                    const data = await fn();
                    if (data.case) onUpdate(data.case);
                } catch (err) {
                    showErr(out, err);
                }
            },
        };

        const title =
            c.subject || t("cat." + c.category) || c.code;
        const meta = [`${t("case.code")}: ${c.code}`, t("status." + c.status), t("cat." + c.category), t("urg." + c.urgency)];
        if (c.ageBand) meta.push(`${t("case.age")}: ${c.ageBand}`);
        if (c.sex) meta.push(`${t("case.sex")}: ${t("sex." + c.sex)}`);

        const people = [];
        if (c.rel !== "patient") {
            people.push(`${t("case.patient")}: ${c.patientName || t("msg.unknown_patient", { code: c.code })}`);
        }
        if (c.generalName && c.rel !== "general") people.push(`${t("case.general")}: ${c.generalName}`);
        if (c.specialistName && c.rel !== "specialist") people.push(`${t("case.specialist")}: ${c.specialistName}`);

        const head = h("div", null,
            h("h2", null, title),
            h("p", { class: "muted" }, meta.join(" | ")),
            people.length ? h("p", { class: "muted" }, people.join(" | ")) : null,
        );

        const refBlock = referralBlock(c, me, ctx);

        // Tabs
        const tabs = [];
        for (const type of ["pg", "gs", "ps"]) {
            if (c.threads[type] !== undefined) {
                tabs.push({ key: type, label: t(`tab.${type}.${c.rel}`), body: () => threadPanel(type, c.threads[type], c, me, ctx) });
            }
        }
        if (c.shared.length || c.rel === "referee") {
            tabs.push({ key: "shared", label: `${t("tab.shared")}${c.shared.length ? " (" + c.shared.length + ")" : ""}`, body: () => sharedPanel(c, me, ctx) });
        }
        if (!tabs.some((x) => x.key === activeTab[c.id])) activeTab[c.id] = tabs.length ? tabs[0].key : null;

        const bar = h("div", { class: "tabs", role: "tablist" });
        const panel = h("div");
        const show = () => {
            const tab = tabs.find((x) => x.key === activeTab[c.id]);
            panel.replaceChildren(tab ? tab.body() : "");
            bar.querySelectorAll("button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.key === activeTab[c.id])));
        };
        tabs.forEach((tab) => {
            bar.append(h("button", {
                type: "button", role: "tab", "data-key": tab.key, class: "tab",
                onclick: () => { activeTab[c.id] = tab.key; show(); },
            }, tab.label));
        });

        // Actions
        const actions = h("div", { class: "actions" });
        if (c.can.shareName) {
            const cb = h("input", { type: "checkbox", checked: c.nameShared });
            cb.addEventListener("change", () => ctx.run(() => api(`/cases/${c.id}/share-name`, "POST", { share: cb.checked })));
            actions.append(h("label", { class: "pick" }, cb, " ", t("act.share_name")));
        }
        const logHolder = h("div", { class: "log-holder" });
        if (c.can.accessLog) {
            actions.append(h("button", { type: "button", class: "alt", onclick: () => accessLog(c, logHolder) }, t("act.access_log")));
        }
        if (c.can.close) {
            actions.append(h("button", {
                type: "button", class: "alt danger-outline",
                onclick: () => { if (confirm(t("act.close_confirm"))) ctx.run(() => api(`/cases/${c.id}/close`, "POST")); },
            }, t("act.close")));
        }

        const builder = c.can.refer ? await referralBuilder(c, me, ctx) : null;
        root.replaceChildren(...[head, refBlock, tabs.length ? bar : null, panel, builder, actions, logHolder, out].filter(Boolean));
        show();
    }

    return { render };
})();
