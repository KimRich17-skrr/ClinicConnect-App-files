onSubmit("#f", async () => {
    await i18nReady;
    try {
        await api("/forgot", "POST", { email: qs("#email").value });
        msg(qs("#out"), t("forgot.sent"), true);
    } catch (err) {
        showErr(qs("#out"), err);
    }
});
