const roleEl = qs("#role");
const typeEl = qs("#dtype");

function syncDoctorFields() {
    qs("#docf").hidden = roleEl.value !== "doctor";
    qs("#specw").hidden = typeEl.value !== "specialist";
}
roleEl.addEventListener("change", syncDoctorFields);
typeEl.addEventListener("change", syncDoctorFields);
syncDoctorFields();

onSubmit("#f", async () => {
    await i18nReady;
    try {
        const res = await api("/signup", "POST", {
            name: qs("#name").value,
            email: qs("#email").value,
            password: qs("#password").value,
            role: roleEl.value,
            doctorType: typeEl.value,
            specialty: qs("#spec").value,
            licenseNo: qs("#lic").value,
            lang: LANG,
        });
        const key = res.approvalPending
            ? "signup.done_pending"
            : res.verified
              ? "signup.done_verified"
              : "signup.done_email";
        msg(qs("#out"), t(key), true);
        qs("#f").reset();
        syncDoctorFields();
    } catch (err) {
        showErr(qs("#out"), err);
    }
});
