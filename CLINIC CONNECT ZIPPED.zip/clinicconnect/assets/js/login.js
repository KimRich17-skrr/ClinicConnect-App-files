onSubmit("#f", async () => {
    await i18nReady;
    qs("#resend").hidden = true;
    try {
        const { user } = await api("/login", "POST", {
            email: qs("#email").value,
            password: qs("#password").value,
        });
        store("cc_lang", user.lang);
        location.href = homeFor(user.role);
    } catch (err) {
        showErr(qs("#out"), err);
        if (err.code === "unverified") qs("#resend").hidden = false;
    }
});

onClick("#resend", async () => {
    try {
        await api("/resend", "POST", { email: qs("#email").value });
        msg(qs("#out"), t("login.resent"), true);
    } catch (err) {
        showErr(qs("#out"), err);
    }
});
