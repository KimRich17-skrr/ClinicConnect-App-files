# Put ClinicConnect online for free (prototype)

This guide uses a free PHP + MySQL host (InfinityFree). It needs no credit card.
You end with a link such as `https://your-name.infinityfreeapp.com`.

Free hosts change their rules. If a step differs on screen, the idea is the same:
make a MySQL database, upload the files, open `setup.php`.

## What you need
- The `clinicconnect` folder from the zip.
- About 20 minutes.
- A phone or laptop for testing.

## Steps

1. **Make the hosting account.** Go to infinityfree.com, sign up, and create a hosting account.
   Choose a free subdomain. Wait until the account shows as active.

2. **Make the database.** In the hosting control panel open *MySQL Databases*, create one database,
   and write down four things: host name (looks like `sql123.infinityfree.com`), database name,
   user name, password.

3. **Upload the files.** Open the *File Manager* (or use FileZilla with the FTP details from the panel).
   Open the `htdocs` folder and upload everything inside `clinicconnect/` so that `index.php`
   sits directly in `htdocs`. Make sure these are included: the `.htaccess` file, and the folders
   `assets`, `lang`, `src` and `storage` (with `storage/audio` and `storage/.htaccess` inside).
   Hidden files are easy to miss in File Manager; FileZilla shows them if you enable
   *Server > Force showing hidden files*.

4. **Create the settings file.** In your browser open `https://YOUR-SITE/setup.php`.
   It prints a block of text. In File Manager create a new file named `config.local.php`
   inside `htdocs`, paste that text, and replace the four `YOUR_DB_...` values with your database details.
   Save the `app_key` line somewhere safe. If it is lost, saved messages and voice clips cannot be read again.

5. **Install.** Open the address the page showed: `https://YOUR-SITE/setup.php?key=...`.
   Read the checklist (all lines except the two optional ones should say OK), then enter a name,
   email and password for the administrator and press *Install*. The page deletes itself.
   If it says it could not, delete `setup.php` yourself in File Manager.

6. **Turn on HTTPS.** Phones only allow the microphone on secure pages. In the control panel
   look for free SSL certificates and switch it on. Then open the site with `https://`.

7. **Approve a doctor.** Open your site, sign up as a patient, then sign up as a doctor
   (general) and as a specialist in private windows. Log in as the administrator
   (`login.php`), open the doctors list and approve both. Doctors cannot log in until you do.

8. **Try it.** Patient: send a case with a voice message. General doctor: take it from the
   *New cases* list, refer it to the specialist. Patient: agree. Specialist: accept.
   Check on the patient's phone that recording works.

9. **Safety check (1 minute).** These addresses must NOT show file contents:
   `/storage/mail.log`, `/src/Auth.php`, `/schema.sql`. A "forbidden" or "not found" page is right.
   If any of them downloads, tell your host's support or move to a host that honours `.htaccess`.

10. **Share the link.** Send `https://YOUR-SITE/` to testers. Tell them it is a prototype.

## Put the code on GitHub (recommended)
```
cd clinicconnect
git init
git add .
git commit -m "ClinicConnect prototype"
# On github.com create a PRIVATE repository, then:
git remote add origin https://github.com/YOU/clinicconnect.git
git branch -M main
git push -u origin main
```
`config.local.php` and voice files are already in `.gitignore`, so passwords and keys stay off GitHub.
Updates: edit, push, then re-upload the changed files (or use the optional
`.github/workflows/deploy-ftp.yml`, which uploads for you; add the three FTP secrets it lists).

## Limits of the free prototype (be honest with testers)
- **No real patient data.** Free hosting has no backups, no uptime promise and no support.
  Use made-up cases only. Before real patients: paid hosting, backups, and the legal steps in the plan.
- **Email may not arrive.** Accounts are verified automatically at sign-up so no email is needed.
  Password-reset emails depend on the host and may not be delivered.
- **Voice to text is off by default.** Voice messages are recorded, stored encrypted and played back.
  Turning on Luganda transcription needs a Sunbird AI token (see README) and a host that allows
  outgoing connections; many free hosts block them. The 10-second limit on free PHP also applies.
- **Audio format.** Chrome and Android record WebM; iPhone Safari records MP4. Old iPhones may not
  play WebM voice notes from Android users.
- **Luganda text is a draft.** Have a native speaker and a clinician review `lang/lg.json`.
- **Free hosts can suspend busy sites** (InfinityFree lists a daily hit limit).

## Other free ways to get a link
- **Quick demo from your own computer:** run XAMPP, copy the folder to `htdocs`, run
  `setup.php`, then share it with a free tunnel such as Cloudflare Tunnel or ngrok. Works only
  while your computer is on.
- **Container hosts** (Render, Railway, Fly.io): use the included `Dockerfile` and an external
  MySQL database. Free tiers sleep when idle and wipe the disk, so voice files would be lost.
