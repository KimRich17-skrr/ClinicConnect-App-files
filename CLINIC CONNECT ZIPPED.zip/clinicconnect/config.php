<?php
declare(strict_types=1);

/**
 * Settings come from environment variables, then from config.local.php
 * (a file you create on the server; it is never committed to Git).
 */
$env = static function (string $key, ?string $default = null): ?string {
    $v = getenv($key);
    return ($v === false || $v === '') ? $default : $v;
};
$bool = static fn(?string $v): bool => filter_var($v, FILTER_VALIDATE_BOOL);

$cfg = [
    'db' => [
        'dsn'  => $env('DB_DSN')
            ?? 'mysql:host=' . $env('DB_HOST', 'localhost')
             . ';dbname=' . $env('DB_NAME', 'clinicconnect') . ';charset=utf8mb4',
        'user' => $env('DB_USER', 'root'),
        'pass' => $env('DB_PASS', ''),
    ],

    // Leave empty to detect from the request.
    'base_url'  => rtrim((string) $env('BASE_URL', ''), '/'),

    // 32 random bytes, base64. Encrypts messages, audio and transcripts.
    // setup.php shows you a fresh one.
    'app_key'   => (string) $env('APP_KEY', ''),

    // Secret that unlocks setup.php (first-time install). Delete setup.php after use.
    'setup_key' => (string) $env('SETUP_KEY', ''),

    // Prototype default: no email server needed, accounts are verified at sign-up.
    // Set to false once email sending works.
    'auto_verify_email' => $bool($env('AUTO_VERIFY_EMAIL', '1')),

    'mail_enabled' => $bool($env('MAIL_ENABLED', '1')),
    'mail_from'    => (string) $env('MAIL_FROM', 'no-reply@example.com'),
    'mail_log'     => $bool($env('MAIL_LOG', '0')), // never turn on in production

    // Behind a proxy/CDN the real visitor IP is in a header.
    'trust_proxy'  => $bool($env('TRUST_PROXY', '1')),

    'default_lang' => (string) $env('DEFAULT_LANG', 'en'),

    'audio' => [
        'max_bytes'   => (int) $env('AUDIO_MAX_BYTES', (string) (3 * 1024 * 1024)),
        'max_seconds' => (int) $env('AUDIO_MAX_SECONDS', '180'),
    ],

    // Speech-to-text. 'none' keeps audio only (doctors listen to the recording).
    // 'sunbird' sends audio to Sunbird AI's API (supports Luganda). Untested here.
    'asr' => [
        'provider' => (string) $env('ASR_PROVIDER', 'none'),
        'url'      => (string) $env('ASR_URL', 'https://api.sunbird.ai/tasks/audio/transcriptions'),
        'token'    => (string) $env('ASR_TOKEN', ''),
        'timeout'  => (int) $env('ASR_TIMEOUT', '8'),
    ],

    'session' => [
        'name'     => 'cc_session',
        'lifetime' => 60 * 60 * 24 * 3,
    ],
];

$local = __DIR__ . '/config.local.php';
if (is_file($local)) {
    $cfg = array_replace_recursive($cfg, (array) require $local);
}

return $cfg;
