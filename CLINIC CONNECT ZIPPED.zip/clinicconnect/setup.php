<?php
declare(strict_types=1);

/**
 * First-time installer. Open it once, then DELETE this file.
 *   1. Without config: shows the text to put in config.local.php.
 *   2. With config:    visit setup.php?key=YOUR_SETUP_KEY to create the tables and the admin.
 */
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Frame-Options: DENY');

$config = require __DIR__ . '/config.php';

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function page(string $title, string $body): never
{
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>' . h($title) . '</title>'
       . '<style>body{font:16px/1.5 system-ui,sans-serif;max-width:720px;margin:32px auto;padding:0 16px;color:#16202e}'
       . 'pre{background:#f1f5f9;padding:12px;overflow:auto;border-radius:8px}'
       . 'input{display:block;width:100%;padding:10px;margin:6px 0 14px;font:inherit}'
       . 'button{padding:10px 18px;font:inherit;background:#0b5cad;color:#fff;border:0;border-radius:8px}'
       . '.ok{color:#05603a}.bad{color:#8a1c12;font-weight:600}</style></head><body>'
       . '<h1>' . h($title) . '</h1>' . $body . '</body></html>';
    exit;
}

// ---- Step 1: no secrets configured yet ------------------------------------
if ($config['setup_key'] === '' || $config['app_key'] === '') {
    $app   = base64_encode(random_bytes(SODIUM_CRYPTO_SECRETBOX_KEYBYTES));
    $setup = bin2hex(random_bytes(16));
    $tpl = "<?php\nreturn [\n"
         . "    'db' => [\n"
         . "        'dsn'  => 'mysql:host=YOUR_DB_HOST;dbname=YOUR_DB_NAME;charset=utf8mb4',\n"
         . "        'user' => 'YOUR_DB_USER',\n"
         . "        'pass' => 'YOUR_DB_PASSWORD',\n"
         . "    ],\n"
         . "    'app_key'   => '$app',\n"
         . "    'setup_key' => '$setup',\n"
         . "];\n";
    page('ClinicConnect setup (step 1 of 2)',
        '<p>Create a file named <code>config.local.php</code> next to this file with the text below, '
        . 'replacing the four YOUR_DB_* values with the database details from your host.</p>'
        . '<p class="bad">Keep the app_key safe and back it up. If you lose it, saved messages and audio cannot be read.</p>'
        . '<pre>' . h($tpl) . '</pre>'
        . '<p>Then open <code>setup.php?key=' . h($setup) . '</code> (use the setup_key from your file).</p>');
}

// ---- Step 2: unlock with the setup key -------------------------------------
$given = (string) ($_REQUEST['key'] ?? '');
if (!hash_equals($config['setup_key'], $given)) {
    http_response_code(403);
    page('Locked', '<p>Open this page as <code>setup.php?key=YOUR_SETUP_KEY</code>.</p>');
}

$checks = [];
$checks[] = [extension_loaded('sodium'), 'PHP sodium extension (encryption)'];
$checks[] = [extension_loaded('pdo_mysql'), 'PHP pdo_mysql extension'];
$checks[] = [is_dir(__DIR__ . '/storage/audio') || @mkdir(__DIR__ . '/storage/audio', 0750, true), 'storage/audio folder exists'];
$checks[] = [is_writable(__DIR__ . '/storage/audio'), 'storage/audio is writable'];
$checks[] = [class_exists('finfo'), 'fileinfo extension (audio type check; optional)'];
$checks[] = [function_exists('curl_init'), 'curl extension (only needed for speech-to-text; optional)'];

$list = '<ul>';
foreach ($checks as [$ok, $label]) {
    $list .= '<li class="' . ($ok ? 'ok' : 'bad') . '">' . ($ok ? 'OK' : 'MISSING') . ' - ' . h($label) . '</li>';
}
$list .= '</ul>';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    page('ClinicConnect setup (step 2 of 2)',
        $list . '<form method="post"><input type="hidden" name="key" value="' . h($given) . '">'
        . '<p>Create the administrator who approves doctors. Admins cannot read patient cases.</p>'
        . '<label>Name<input name="name" required maxlength="80"></label>'
        . '<label>Email<input name="email" type="email" required></label>'
        . '<label>Password (8+ characters, letter and number)<input name="password" type="password" required minlength="8"></label>'
        . '<button>Install</button></form>');
}

// ---- POST: install ----------------------------------------------------------
$name  = trim((string) ($_POST['name'] ?? ''));
$email = strtolower(trim((string) ($_POST['email'] ?? '')));
$pass  = (string) ($_POST['password'] ?? '');

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || strlen($pass) < 8 || !preg_match('/[a-z]/i', $pass) || !preg_match('/\d/', $pass)) {
    page('Check the form', $list . '<p class="bad">Enter a name, a valid email and a password with 8+ characters, a letter and a number.</p>');
}

try {
    $pdo = new PDO($config['db']['dsn'], $config['db']['user'], $config['db']['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    $sql = (string) file_get_contents(__DIR__ . '/schema.sql');
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    foreach (array_filter(array_map('trim', explode(';', (string) $sql))) as $stmt) {
        $pdo->exec($stmt);
    }
    $has = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
    if ($has === 0) {
        $st = $pdo->prepare(
            "INSERT INTO users (name, email, password_hash, role, approved, verified, lang)
             VALUES (?, ?, ?, 'admin', 1, 1, 'en')"
        );
        $st->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT)]);
        $msg = '<p class="ok">Tables created and the administrator was added.</p>';
    } else {
        $msg = '<p class="ok">Tables are up to date. An administrator already exists, so none was added.</p>';
    }
} catch (Throwable $e) {
    error_log((string) $e);
    page('Install failed', '<p class="bad">Could not reach or write the database. Check the details in config.local.php.</p>'
        . '<p>' . h($e->getMessage()) . '</p>');
}

$gone = @unlink(__FILE__);
page('Done',
    $msg
    . ($gone
        ? '<p class="ok">setup.php deleted itself.</p>'
        : '<p class="bad">Delete setup.php from your server now (this host would not let it delete itself).</p>')
    . '<p><a href="login.php">Go to the app</a></p>');
