<?php require __DIR__ . '/src/layout.php'; cc_page_start('forgot.title'); ?>
<main class="narrow">
  <div class="card">
    <h1 data-i18n="forgot.title"></h1>
    <p class="muted" data-i18n="forgot.lead"></p>
    <form id="f">
      <label for="email" data-i18n="field.email"></label>
      <input id="email" type="email" required>
      <button data-i18n="forgot.submit"></button>
    </form>
    <p><a href="login.php" data-i18n="forgot.back"></a></p>
    <div id="out" class="msg" hidden role="status"></div>
  </div>
</main>
<?php cc_page_end(['forgot']); ?>
