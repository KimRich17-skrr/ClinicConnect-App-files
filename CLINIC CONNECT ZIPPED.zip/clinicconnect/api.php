<?php
declare(strict_types=1);

$config = require __DIR__ . '/src/bootstrap.php';

set_exception_handler(function (Throwable $e): void {
    error_log((string) $e);
    Response::fail('server_error', 500);
});

$ip        = cc_client_ip($config);
$baseUrl   = cc_base_url($config);
$db        = new Database($config['db']);
try {
    $crypto = new Crypto($config['app_key']);
} catch (RuntimeException) {
    Response::fail('server_misconfigured', 500);
}
$mailer    = new Mailer($config['mail_from'], $config['mail_enabled'], $config['mail_log'], __DIR__ . '/storage/mail.log');
$auth      = new Auth($db, $mailer, $baseUrl);
$cases     = new CaseService($db, $crypto);
$audit     = new Audit($db, $ip);
$throttle  = new Throttle($db);
$audio     = new Audio($db, $crypto, __DIR__ . '/storage/audio', $config['audio']);
$asr       = new Asr($config['asr']);
$req       = new Router();

const DUMMY_HASH = '$2y$10$usesomesillystringfore7hnbRJHxXVLeakoG8K30oukPsA.ztMG';

// =====================================================================
//  Public routes
// =====================================================================

if ($req->is('POST', '/signup')) {
    if (!$throttle->hit("signup:$ip", 15, 3600)) {
        Response::fail('too_many', 429);
    }
    $email = Validator::email($req->body('email'));
    $name  = Validator::str($req->body('name'), 80);
    $pass  = $req->body('password');
    $lang  = Validator::oneOf($req->body('lang'), Validator::LANGS, $config['default_lang']);

    if ($name === '') {
        Response::fail('name_required');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        Response::fail('email_invalid');
    }
    if (!Validator::passwordOk($pass)) {
        Response::fail('password_weak');
    }
    if ($db->one('SELECT 1 FROM users WHERE email = ?', [$email])) {
        Response::fail('email_taken', 409);
    }

    $role = $req->body('role') === 'doctor' ? 'doctor' : 'patient';
    $docType = $specialty = $license = null;

    if ($role === 'doctor') {
        $docType = $req->body('doctorType') === 'specialist' ? 'specialist' : 'general';
        $specialty = $docType === 'specialist'
            ? Validator::str($req->body('specialty'), 60)
            : 'General practice';
        $license = Validator::str($req->body('licenseNo'), 40);

        if ($specialty === '') {
            Response::fail('specialty_required');
        }
        if (mb_strlen($license) < 4) {
            Response::fail('license_required');
        }
    }

    $verifiedNow = $config['auto_verify_email'] ? 1 : 0;
    $approved    = $role === 'doctor' ? 0 : 1; // doctors wait for an admin

    try {
        $db->run(
            'INSERT INTO users (name, email, password_hash, role, doctor_type, specialty, license_no, approved, verified, lang)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$name, $email, password_hash((string) $pass, PASSWORD_DEFAULT), $role, $docType, $specialty, $license, $approved, $verifiedNow, $lang]
        );
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            Response::fail('email_taken', 409);
        }
        throw $e;
    }

    if (!$verifiedNow) {
        $auth->sendVerify(['id' => $db->lastId(), 'name' => $name, 'email' => $email, 'lang' => $lang]);
    }

    Response::json([
        'ok'              => true,
        'verified'        => (bool) $verifiedNow,
        'approvalPending' => $role === 'doctor',
    ], 201);
}

if ($req->is('GET', '/verify')) {
    $token = $auth->findToken((string) $req->query('token', ''), 'verify');
    if ($token === null) {
        Response::fail('link_invalid');
    }
    $db->run('UPDATE users SET verified = 1 WHERE id = ?', [(int) $token['user_id']]);
    $db->run('DELETE FROM tokens WHERE id = ?', [(int) $token['id']]);
    Response::json(['ok' => true]);
}

if ($req->is('POST', '/resend')) {
    $email = Validator::email($req->body('email'));
    if ($throttle->hit("resend:$ip", 10, 3600) && $throttle->hit("resend:$email", 3, 3600)) {
        $user = $db->one('SELECT * FROM users WHERE email = ?', [$email]);
        if ($user && !$user['verified']) {
            $auth->sendVerify($user);
        }
    }
    Response::json(['ok' => true]);
}

if ($req->is('POST', '/login')) {
    $email = Validator::email($req->body('email'));
    $kEmail = "login:$email";
    $kIp    = "loginip:$ip";

    if ($throttle->blocked($kEmail, 5, 900) || $throttle->blocked($kIp, 40, 900)) {
        Response::fail('too_many', 429);
    }

    $user = $db->one('SELECT * FROM users WHERE email = ?', [$email]);
    $ok = password_verify((string) $req->body('password'), $user['password_hash'] ?? DUMMY_HASH);
    if (!$user || !$ok) {
        $throttle->hit($kEmail, 5, 900);
        $throttle->hit($kIp, 40, 900);
        Response::fail('bad_credentials', 401);
    }
    if (!$user['verified']) {
        Response::fail('unverified', 403);
    }
    if ($user['role'] === 'doctor' && !$user['approved']) {
        Response::fail('pending_approval', 403);
    }

    $throttle->clear($kEmail);
    session_regenerate_id(true);
    $_SESSION['uid'] = (int) $user['id'];
    $audit->log((int) $user['id'], null, 'login');

    Response::json(['user' => $auth->publicUser($user)]);
}

if ($req->is('POST', '/forgot')) {
    $email = Validator::email($req->body('email'));
    if ($throttle->hit("forgot:$ip", 10, 3600) && $throttle->hit("forgot:$email", 3, 3600)) {
        $user = $db->one('SELECT * FROM users WHERE email = ?', [$email]);
        if ($user) {
            $auth->sendReset($user);
        }
    }
    Response::json(['ok' => true]);
}

if ($req->is('POST', '/reset')) {
    $token = $auth->findToken((string) $req->body('token'), 'reset');
    if ($token === null) {
        Response::fail('link_invalid');
    }
    if (!Validator::passwordOk($req->body('password'))) {
        Response::fail('password_weak');
    }
    $db->run('UPDATE users SET password_hash = ? WHERE id = ?', [
        password_hash((string) $req->body('password'), PASSWORD_DEFAULT),
        (int) $token['user_id'],
    ]);
    $db->run("DELETE FROM tokens WHERE user_id = ? AND type = 'reset'", [(int) $token['user_id']]);
    Response::json(['ok' => true]);
}

// =====================================================================
//  Everything below needs a signed-in user
// =====================================================================

$me  = $auth->requireLogin();
$uid = (int) $me['id'];
$isPatient = $me['role'] === 'patient';
$isGeneral = $me['role'] === 'doctor' && $me['doctor_type'] === 'general';
$isSpecialist = $me['role'] === 'doctor' && $me['doctor_type'] === 'specialist';
$isAdmin = $me['role'] === 'admin';

if ($req->is('GET', '/me')) {
    Response::json(['user' => $auth->publicUser($me), 'features' => ['asr' => $asr->enabled()]]);
}

if ($req->is('POST', '/logout')) {
    $_SESSION = [];
    session_destroy();
    Response::json(['ok' => true]);
}

if ($req->is('POST', '/lang')) {
    $lang = Validator::oneOf($req->body('lang'), Validator::LANGS);
    if ($lang === null) {
        Response::fail('bad_request');
    }
    $db->run('UPDATE users SET lang = ? WHERE id = ?', [$lang, $uid]);
    Response::json(['ok' => true]);
}

// ---------------------------------------------------------------------
//  Admin: approve doctors. Admins cannot read any case.
// ---------------------------------------------------------------------

if ($isAdmin) {
    if ($req->is('GET', '/admin/doctors')) {
        $rows = $db->all(
            "SELECT id, name, email, doctor_type, specialty, license_no, approved,
                    UNIX_TIMESTAMP(created_at) * 1000 AS at
             FROM users WHERE role = 'doctor' ORDER BY approved, created_at DESC"
        );
        Response::json(['doctors' => array_map(static fn(array $d): array => [
            'id'         => (int) $d['id'],
            'name'       => $d['name'],
            'email'      => $d['email'],
            'doctorType' => $d['doctor_type'],
            'specialty'  => $d['specialty'],
            'licenseNo'  => $d['license_no'],
            'approved'   => (bool) $d['approved'],
            'at'         => (int) $d['at'],
        ], $rows)]);
    }

    if (($m = $req->match('POST', '#^/admin/doctors/(\d+)/(approve|suspend|reject)$#')) !== null) {
        $doctorId = (int) $m[0];
        $row = $db->one("SELECT * FROM users WHERE id = ? AND role = 'doctor'", [$doctorId]);
        if ($row === null) {
            Response::fail('not_found', 404);
        }
        if ($m[1] === 'approve') {
            $db->run('UPDATE users SET approved = 1 WHERE id = ?', [$doctorId]);
        } elseif ($m[1] === 'suspend') {
            $db->run('UPDATE users SET approved = 0 WHERE id = ?', [$doctorId]);
        } else { // reject: only a doctor who never had access
            $db->run("DELETE FROM users WHERE id = ? AND role = 'doctor' AND approved = 0
                      AND NOT EXISTS (SELECT 1 FROM cases WHERE general_id = ? OR specialist_id = ?)",
                [$doctorId, $doctorId, $doctorId]);
        }
        $audit->log($uid, null, 'admin.' . $m[1], 'doctor #' . $doctorId);
        Response::json(['ok' => true]);
    }

    Response::fail('forbidden', 403);
}

// ---------------------------------------------------------------------
//  Lists
// ---------------------------------------------------------------------

if ($req->is('GET', '/specialists') && $isGeneral) {
    $rows = $db->all(
        "SELECT id, name, specialty FROM users
         WHERE doctor_type = 'specialist' AND approved = 1 AND verified = 1 ORDER BY name"
    );
    Response::json(['specialists' => array_map(static fn(array $r): array => [
        'id' => (int) $r['id'], 'name' => $r['name'], 'specialty' => $r['specialty'],
    ], $rows)]);
}

if ($req->is('GET', '/cases')) {
    Response::json(['cases' => $cases->listFor($me)]);
}

// Unclaimed cases: category, urgency, language, age band, sex. Nothing identifying.
if ($req->is('GET', '/pool')) {
    if (!$isGeneral) {
        Response::fail('forbidden', 403);
    }
    Response::json(['pool' => $cases->pool()]);
}

// ---------------------------------------------------------------------
//  Helper: store an uploaded voice clip for a message and try to transcribe
// ---------------------------------------------------------------------

$attachAudio = function (int $messageId, array $up, int $seconds, string $lang) use ($audio, $asr): void {
    $clipId = $audio->store($messageId, $up, $seconds);
    if ($asr->enabled()) {
        $text = $asr->transcribe((string) file_get_contents($up['tmp']), $up['mime'], $lang);
        $audio->saveTranscript($clipId, $text);
    }
};

// ---------------------------------------------------------------------
//  Create a case (patient)
// ---------------------------------------------------------------------

if ($req->is('POST', '/cases')) {
    if (!$isPatient) {
        Response::fail('forbidden', 403);
    }
    if (!$throttle->hit("newcase:$uid", 10, 3600)) {
        Response::fail('too_many', 429);
    }

    $category = Validator::oneOf($req->body('category'), Validator::CATEGORIES);
    $urgency  = Validator::oneOf($req->body('urgency'), Validator::URGENCY, 'routine');
    $ageBand  = Validator::oneOf($req->body('ageBand'), Validator::AGE_BANDS);
    $sex      = Validator::oneOf($req->body('sex'), Validator::SEX);
    $subject  = Validator::str($req->body('subject'), 120);
    $text     = Validator::str($req->body('text'));
    $seconds  = (int) $req->body('seconds', 0);
    $up       = $audio->validate($req->file('audio'));

    if ($category === null) {
        Response::fail('category_required');
    }
    if ($text === '' && $up === null) {
        Response::fail('message_required');
    }

    $db->begin();
    try {
        $db->run(
            'INSERT INTO cases (patient_id, code, category, urgency, lang, age_band, sex, subject)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [$uid, $cases->newCode(), $category, $urgency, $me['lang'], $ageBand, $sex, $subject]
        );
        $caseId = $db->lastId();
        $tid    = $cases->ensureThread($caseId, 'pg');
        $mid    = $cases->addMessage($tid, $uid, $text);
        if ($up !== null) {
            $attachAudio($mid, $up, $seconds, $me['lang']);
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }

    $audit->log($uid, $caseId, 'case.create');
    Response::json(['case' => $cases->view($caseId, $me)], 201);
}

// ---------------------------------------------------------------------
//  Audio playback and (re)transcription
// ---------------------------------------------------------------------

if (($m = $req->match('GET', '#^/audio/(\d+)$#')) !== null) {
    $clip = $audio->read((int) $m[0]);
    $msg  = $clip === null ? null : $cases->messageRow($clip['message_id']);
    $case = $msg === null ? null : $cases->row((int) $msg['case_id']);
    $rel  = $case === null ? null : $cases->relation($me, $case);

    if ($rel === null || !$cases->canViewMessage($me, $case, $rel, $msg)) {
        Response::fail('not_found', 404);
    }
    if (!$isPatient) {
        $audit->log($uid, (int) $case['id'], 'audio.play');
    }
    http_response_code(200);
    header('Content-Type: ' . $clip['mime']);
    header('Content-Length: ' . strlen($clip['data']));
    header('Cache-Control: private, no-store');
    echo $clip['data'];
    exit;
}

if (($m = $req->match('POST', '#^/audio/(\d+)/transcribe$#')) !== null) {
    $clipRow = $db->one('SELECT * FROM audio_clips WHERE id = ?', [(int) $m[0]]);
    $msg  = $clipRow === null ? null : $cases->messageRow((int) $clipRow['message_id']);
    $case = $msg === null ? null : $cases->row((int) $msg['case_id']);
    $rel  = $case === null ? null : $cases->relation($me, $case);

    if ($rel === null || !$cases->canViewMessage($me, $case, $rel, $msg)) {
        Response::fail('not_found', 404);
    }
    if (!$asr->enabled()) {
        Response::fail('asr_off');
    }
    if (!$throttle->hit("asr:$uid", 20, 3600)) {
        Response::fail('too_many', 429);
    }
    $clip = $audio->read((int) $m[0]);
    if ($clip !== null) {
        $audio->saveTranscript((int) $m[0], $asr->transcribe($clip['data'], $clip['mime'], (string) $case['lang']));
    }
    Response::json(['case' => $cases->view((int) $case['id'], $me)]);
}

// ---------------------------------------------------------------------
//  Per-case routes
// ---------------------------------------------------------------------

if (preg_match('#^/cases/(\d+)(?:/(.+))?$#', $req->path(), $cm) === 1) {
    $caseId = (int) $cm[1];
    $sub    = $cm[2] ?? '';

    $case = $cases->row($caseId);

    // Claiming is the one action open to a doctor with no relation yet.
    if ($sub === 'claim' && $req->method() === 'POST') {
        if (!$isGeneral) {
            Response::fail('forbidden', 403);
        }
        $n = $db->run(
            "UPDATE cases SET status = 'with_general', general_id = ? WHERE id = ? AND status = 'new'",
            [$uid, $caseId]
        )->rowCount();
        if ($n === 0) {
            Response::fail('already_taken', 409);
        }
        $cases->system($caseId, 'pg', 'sys.claimed', ['name' => $me['name']]);
        $audit->log($uid, $caseId, 'case.claim');
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    $rel = $case === null ? null : $cases->relation($me, $case);
    if ($case === null || $rel === null) {
        Response::fail('not_found', 404);
    }
    $open = $case['status'] !== 'closed';

    // ---- GET /cases/{id}
    if ($sub === '' && $req->method() === 'GET') {
        if ($rel !== 'patient') {
            $audit->log($uid, $caseId, 'case.view');
        }
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    // ---- GET /cases/{id}/access-log   (patient only)
    if ($sub === 'access-log' && $req->method() === 'GET') {
        if ($rel !== 'patient') {
            Response::fail('forbidden', 403);
        }
        $rows = $db->all(
            "SELECT a.action, u.name, u.specialty, u.doctor_type, UNIX_TIMESTAMP(a.created_at) * 1000 AS at
             FROM audit_log a JOIN users u ON u.id = a.user_id
             WHERE a.case_id = ? AND a.user_id <> ? AND a.action IN
               ('case.view','audio.play','case.claim','referral.create','referral.accept','message.share')
             ORDER BY a.id DESC LIMIT 100",
            [$caseId, $uid]
        );
        Response::json(['log' => array_map(static fn(array $r): array => [
            'action' => $r['action'], 'name' => $r['name'], 'specialty' => $r['specialty'], 'at' => (int) $r['at'],
        ], $rows)]);
    }

    if ($req->method() !== 'POST') {
        Response::fail('not_found', 404);
    }
    if (!$open) {
        Response::fail('case_closed');
    }

    // ---- POST /cases/{id}/messages
    if ($sub === 'messages') {
        $type = Validator::oneOf($req->body('thread'), ['pg', 'gs', 'ps']);
        if ($type === null || !$cases->inThread($rel, $type)) {
            Response::fail('forbidden', 403);
        }
        $tid = $cases->threadId($caseId, $type);
        if ($tid === null) {
            Response::fail('forbidden', 403);
        }
        if (!$throttle->hit("msg:$uid", 120, 3600)) {
            Response::fail('too_many', 429);
        }
        $text    = Validator::str($req->body('text'));
        $seconds = (int) $req->body('seconds', 0);
        $up      = $audio->validate($req->file('audio'));
        if ($text === '' && $up === null) {
            Response::fail('message_required');
        }
        $db->begin();
        try {
            $mid = $cases->addMessage($tid, $uid, $text);
            if ($up !== null) {
                $attachAudio($mid, $up, $seconds, (string) $case['lang']);
            }
            $db->commit();
        } catch (Throwable $e) {
            $db->rollback();
            throw $e;
        }
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    // ---- POST /cases/{id}/messages/{mid}/share | unshare
    if (preg_match('#^messages/(\d+)/(share|unshare)$#', $sub, $sm) === 1) {
        $msg = $cases->messageRow((int) $sm[1]);
        if ($msg === null || (int) $msg['case_id'] !== $caseId || $msg['is_system'] || !$cases->inThread($rel, $msg['ttype'])) {
            Response::fail('not_found', 404);
        }
        $with = Validator::oneOf($req->body('with'), ['patient', 'general', 'specialist']);
        $targetId = match ($with) {
            'patient'    => (int) $case['patient_id'],
            'general'    => (int) ($case['general_id'] ?? 0),
            'specialist' => (int) ($case['specialist_id'] ?? 0),
            default      => 0,
        };
        if ($targetId === 0 || $cases->inThread($with, $msg['ttype'])) {
            Response::fail('bad_request');
        }
        if ($sm[2] === 'share') {
            $db->run(
                'INSERT IGNORE INTO message_shares (message_id, with_user_id, shared_by) VALUES (?, ?, ?)',
                [(int) $msg['id'], $targetId, $uid]
            );
            $cases->system($caseId, $msg['ttype'], 'sys.shared', ['by' => $rel, 'with' => $with]);
            $audit->log($uid, $caseId, 'message.share', "to $with");
        } else {
            $gone = $db->run(
                'DELETE FROM message_shares WHERE message_id = ? AND with_user_id = ? AND shared_by = ?',
                [(int) $msg['id'], $targetId, $uid]
            )->rowCount();
            if ($gone === 0) {
                Response::fail('forbidden', 403);
            }
            $cases->system($caseId, $msg['ttype'], 'sys.unshared', ['by' => $rel, 'with' => $with]);
            $audit->log($uid, $caseId, 'message.unshare', "from $with");
        }
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    // ---- POST /cases/{id}/share-name   (patient decides who learns their name)
    if ($sub === 'share-name') {
        if ($rel !== 'patient') {
            Response::fail('forbidden', 403);
        }
        $share = $req->body('share') ? 1 : 0;
        $db->run('UPDATE cases SET name_shared = ? WHERE id = ?', [$share, $caseId]);
        $audit->log($uid, $caseId, $share ? 'name.share' : 'name.hide');
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    // ---- POST /cases/{id}/referral   (general doctor)
    if ($sub === 'referral') {
        if ($rel !== 'general' || $case['status'] !== 'with_general' || $cases->hasActiveReferral($caseId)) {
            Response::fail('forbidden', 403);
        }
        $spec = $db->one(
            "SELECT * FROM users WHERE id = ? AND doctor_type = 'specialist' AND approved = 1 AND verified = 1",
            [(int) $req->body('specialistId', 0)]
        );
        $summary = Validator::str($req->body('summary'), 1500);
        if ($spec === null) {
            Response::fail('specialist_required');
        }
        if ($summary === '') {
            Response::fail('summary_required');
        }
        $ids = Validator::ids($req->body('messageIds'), 30);
        if ($ids !== []) {
            $in = implode(',', array_fill(0, count($ids), '?'));
            $ids = array_map('intval', $db->column(
                "SELECT m.id FROM messages m JOIN threads t ON t.id = m.thread_id
                 WHERE t.case_id = ? AND t.type = 'pg' AND m.is_system = 0 AND m.id IN ($in)",
                array_merge([$caseId], $ids)
            ));
        }
        $db->begin();
        try {
            $db->run(
                'INSERT INTO referrals (case_id, general_id, specialist_id, summary, include_name)
                 VALUES (?, ?, ?, ?, ?)',
                [$caseId, $uid, (int) $spec['id'], $crypto->seal($summary), $req->body('includeName') ? 1 : 0]
            );
            $rid = $db->lastId();
            foreach ($ids as $mid) {
                $db->run('INSERT INTO referral_items (referral_id, message_id) VALUES (?, ?)', [$rid, $mid]);
            }
            $cases->system($caseId, 'pg', 'sys.referral_requested', [
                'name' => $spec['name'], 'specialty' => $spec['specialty'],
            ]);
            $db->commit();
        } catch (Throwable $e) {
            $db->rollback();
            throw $e;
        }
        $audit->log($uid, $caseId, 'referral.create', 'to #' . (int) $spec['id']);
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    $ref = $cases->latestReferral($caseId);

    // ---- POST /cases/{id}/referral/consent   (patient)
    if ($sub === 'referral/consent') {
        if ($rel !== 'patient' || $ref === null || $ref['status'] !== 'awaiting_consent') {
            Response::fail('forbidden', 403);
        }
        $allow = (bool) $req->body('allow');
        $db->run('UPDATE referrals SET status = ? WHERE id = ?', [$allow ? 'pending' : 'declined_patient', (int) $ref['id']]);
        $cases->system($caseId, 'pg', $allow ? 'sys.referral_consented' : 'sys.referral_declined_patient');
        $audit->log($uid, $caseId, $allow ? 'referral.consent' : 'referral.refuse');
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    // ---- POST /cases/{id}/referral/withdraw   (general doctor)
    if ($sub === 'referral/withdraw') {
        if ($rel !== 'general' || $ref === null || !in_array($ref['status'], ['awaiting_consent', 'pending'], true)) {
            Response::fail('forbidden', 403);
        }
        $db->run("UPDATE referrals SET status = 'withdrawn' WHERE id = ?", [(int) $ref['id']]);
        $cases->system($caseId, 'pg', 'sys.referral_withdrawn');
        $audit->log($uid, $caseId, 'referral.withdraw');
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    // ---- POST /cases/{id}/referral/respond   (the specialist it names)
    if ($sub === 'referral/respond') {
        if ($rel !== 'referee' || $ref === null || $ref['status'] !== 'pending') {
            Response::fail('forbidden', 403);
        }
        if ($req->body('accept')) {
            $db->begin();
            try {
                $db->run("UPDATE referrals SET status = 'accepted' WHERE id = ?", [(int) $ref['id']]);
                $db->run(
                    "UPDATE cases SET specialist_id = ?, status = 'with_specialist',
                            name_shared = IF(?, 1, name_shared) WHERE id = ?",
                    [$uid, (int) $ref['include_name'], $caseId]
                );
                $cases->ensureThread($caseId, 'gs');
                $cases->ensureThread($caseId, 'ps');
                $cases->system($caseId, 'pg', 'sys.specialist_joined', ['name' => $me['name'], 'specialty' => $me['specialty']]);
                $cases->system($caseId, 'gs', 'sys.consult_open');
                $cases->system($caseId, 'ps', 'sys.specialist_chat_open');
                $db->commit();
            } catch (Throwable $e) {
                $db->rollback();
                throw $e;
            }
            $audit->log($uid, $caseId, 'referral.accept');
        } else {
            $db->run("UPDATE referrals SET status = 'declined_specialist' WHERE id = ?", [(int) $ref['id']]);
            $cases->system($caseId, 'pg', 'sys.referral_declined_specialist');
            $audit->log($uid, $caseId, 'referral.decline');
        }
        Response::json(['case' => $cases->view($caseId, $me)]);
    }

    // ---- POST /cases/{id}/close
    if ($sub === 'close') {
        if ($rel === 'referee') {
            Response::fail('forbidden', 403);
        }
        $db->run("UPDATE cases SET status = 'closed' WHERE id = ?", [$caseId]);
        $cases->system($caseId, 'pg', 'sys.closed', ['by' => $rel]);
        $audit->log($uid, $caseId, 'case.close');
        Response::json(['case' => $cases->view($caseId, $me)]);
    }
}

Response::fail('not_found', 404);
