<?php
declare(strict_types=1);

/** Shared page frame. Pages are plain HTML; all words come from lang/*.json in the browser. */

function cc_page_start(string $titleKey, array $css = []): void
{
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; media-src 'self' blob:; "
        . "script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: camera=(), geolocation=(), microphone=(self)');
    header('Cache-Control: no-store');

    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>ClinicConnect</title>'
       . '<link rel="stylesheet" href="assets/css/base.css">';
    foreach ($css as $file) {
        echo '<link rel="stylesheet" href="assets/css/' . htmlspecialchars($file, ENT_QUOTES) . '.css">';
    }
    echo '</head><body data-title="' . htmlspecialchars($titleKey, ENT_QUOTES) . '">'
       . '<header><a class="brand" href="index.php">ClinicConnect</a>'
       . '<nav id="nav"><a href="login.php" data-i18n="nav.login"></a><a href="signup.php" data-i18n="nav.signup"></a>'
       . '<select id="lang" aria-label="Language"><option value="en">English</option><option value="lg">Oluganda</option></select>'
       . '</nav></header>'
       . '<p id="draft" class="draft" hidden></p>';
}

function cc_page_end(array $scripts): void
{
    echo '<script src="assets/js/api.js"></script>';
    foreach ($scripts as $file) {
        echo '<script src="assets/js/' . htmlspecialchars($file, ENT_QUOTES) . '.js"></script>';
    }
    echo '</body></html>';
}
