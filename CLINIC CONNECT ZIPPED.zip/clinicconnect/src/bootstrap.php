<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

$config = require __DIR__ . '/../config.php';

spl_autoload_register(function (string $class): void {
    $file = __DIR__ . '/' . $class . '.php';
    if (is_file($file)) {
        require $file;
    }
});

function cc_is_https(): bool
{
    return !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'
        || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}

function cc_client_ip(array $config): string
{
    if ($config['trust_proxy']) {
        $cf = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '';
        if ($cf !== '') {
            return substr($cf, 0, 45);
        }
        $xff = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
        if ($xff !== '') {
            return substr(trim(explode(',', $xff)[0]), 0, 45);
        }
    }
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

function cc_base_url(array $config): string
{
    if ($config['base_url'] !== '') {
        return $config['base_url'];
    }
    $scheme = cc_is_https() ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme . '://' . $host . $dir;
}

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: camera=(), geolocation=(), microphone=(self)');
if (cc_is_https()) {
    header('Strict-Transport-Security: max-age=31536000');
}

session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Lax',
    'secure'   => cc_is_https(),
    'lifetime' => $config['session']['lifetime'],
    'path'     => '/',
]);
session_name($config['session']['name']);
session_start();

return $config;
