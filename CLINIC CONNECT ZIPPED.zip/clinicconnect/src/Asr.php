<?php
declare(strict_types=1);

/**
 * Speech-to-text adapter. Swap the provider here without touching the rest of the app.
 * Provider "sunbird" posts the audio to Sunbird AI (supports Luganda). The request shape
 * follows Sunbird's published docs but has not been run against the live service; check
 * it with a real token before relying on it. Failures never block a message: the doctor
 * can always play the recording.
 */
final class Asr
{
    private const LANG_CODES = ['en' => 'eng', 'lg' => 'lug'];
    private const EXT = [
        'audio/webm' => 'webm', 'audio/ogg' => 'ogg', 'audio/mp4' => 'm4a',
        'audio/mpeg' => 'mp3', 'audio/wav' => 'wav', 'audio/aac' => 'aac',
    ];

    public function __construct(private readonly array $cfg) {}

    public function enabled(): bool
    {
        return $this->cfg['provider'] === 'sunbird'
            && $this->cfg['token'] !== ''
            && function_exists('curl_init');
    }

    public function transcribe(string $audio, string $mime, string $lang): ?string
    {
        if (!$this->enabled()) {
            return null;
        }
        $tmp = tempnam(sys_get_temp_dir(), 'cc');
        if ($tmp === false) {
            return null;
        }
        $file = $tmp . '.' . (self::EXT[$mime] ?? 'bin');
        rename($tmp, $file);

        try {
            file_put_contents($file, $audio);
            $ch = curl_init($this->cfg['url']);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => max(3, (int) $this->cfg['timeout']),
                CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $this->cfg['token']],
                CURLOPT_POSTFIELDS     => [
                    'audio'    => new CURLFile($file, $mime, 'clip.' . (self::EXT[$mime] ?? 'bin')),
                    'language' => self::LANG_CODES[$lang] ?? 'lug',
                ],
            ]);
            $raw  = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if (!is_string($raw) || $code < 200 || $code >= 300) {
                return null;
            }
            $d = json_decode($raw, true);
            if (!is_array($d)) {
                return null;
            }
            foreach (['audio_transcription', 'transcription', 'transcript', 'text'] as $k) {
                if (isset($d[$k]) && is_string($d[$k]) && trim($d[$k]) !== '') {
                    return $d[$k];
                }
            }
            return null;
        } finally {
            @unlink($file);
        }
    }
}
