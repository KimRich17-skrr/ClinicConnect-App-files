<?php
declare(strict_types=1);

final class Response
{
    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    /** $code is a stable key; the browser translates it (lang/*.json, "err.<code>"). */
    public static function fail(string $code, int $status = 400): never
    {
        self::json(['error' => $code, 'code' => $code], $status);
    }
}
