<?php
declare(strict_types=1);

final class Router
{
    private string $method;
    private string $path;
    private array $query = [];
    private array $body = [];
    private array $files = [];

    public function __construct()
    {
        $route = parse_url((string) ($_GET['r'] ?? '/'));
        $this->path = $route['path'] ?? '/';
        parse_str($route['query'] ?? '', $this->query);

        $this->method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

        if ($this->method === 'POST') {
            // Cross-site forms cannot set this header, which blocks CSRF.
            if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'cc') {
                Response::fail('bad_request', 400);
            }
            $ctype = strtolower($_SERVER['CONTENT_TYPE'] ?? '');
            if (str_contains($ctype, 'application/json')) {
                $decoded = json_decode((string) file_get_contents('php://input'), true);
                $this->body = is_array($decoded) ? $decoded : [];
            } elseif (str_contains($ctype, 'multipart/form-data')) {
                $this->body  = $_POST;
                $this->files = $_FILES;
            } elseif ($ctype === '' && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) === 0) {
                $this->body = []; // action buttons with nothing to send
            } else {
                Response::fail('bad_request', 415);
            }
        }
    }

    public function method(): string { return $this->method; }
    public function path(): string   { return $this->path; }

    public function query(string $key, mixed $default = null): mixed
    {
        return $this->query[$key] ?? $default;
    }

    public function body(string $key, mixed $default = null): mixed
    {
        return $this->body[$key] ?? $default;
    }

    public function file(string $key): ?array
    {
        return $this->files[$key] ?? null;
    }

    public function is(string $method, string $path): bool
    {
        return $this->method === $method && $this->path === $path;
    }

    /**
     * Match a regex against the path. Returns the captures (without the full
     * match) or null. Only for the given method.
     * @return array<int,string>|null
     */
    public function match(string $method, string $pattern): ?array
    {
        if ($this->method !== $method) {
            return null;
        }
        if (preg_match($pattern, $this->path, $m) === 1) {
            array_shift($m);
            return $m;
        }
        return null;
    }
}
