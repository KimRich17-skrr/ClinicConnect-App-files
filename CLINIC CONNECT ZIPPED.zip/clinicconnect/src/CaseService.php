<?php
declare(strict_types=1);

/**
 * All reading of case data goes through this class, and every read starts
 * from relation(): who is this user to this case? A user who has no relation
 * gets "not found". Visibility then follows three rules:
 *
 *   1. Conversation membership: pg = patient+general, gs = general+specialist,
 *      ps = patient+specialist.
 *   2. An explicit message share (message_shares) with that one person.
 *   3. A referral the patient has consented to, for the specialist it names.
 */
final class CaseService
{
    /** Which relations belong to which conversation. "referee" is in none. */
    private const MEMBERS = [
        'pg' => ['patient', 'general'],
        'gs' => ['general', 'specialist'],
        'ps' => ['patient', 'specialist'],
    ];

    public function __construct(
        private readonly Database $db,
        private readonly Crypto $crypto
    ) {}

    // =================================================================
    //  Relation and permissions
    // =================================================================

    public function row(int $id): ?array
    {
        return $this->db->one('SELECT * FROM cases WHERE id = ?', [$id]);
    }

    /** patient | general | specialist | referee | null */
    public function relation(array $user, array $case): ?string
    {
        $uid = (int) $user['id'];

        if ($user['role'] === 'patient') {
            return (int) $case['patient_id'] === $uid ? 'patient' : null;
        }
        if ($user['role'] !== 'doctor') {
            return null;
        }
        if ($case['general_id'] !== null && (int) $case['general_id'] === $uid) {
            return 'general';
        }
        if ($case['specialist_id'] !== null && (int) $case['specialist_id'] === $uid) {
            return 'specialist';
        }
        $ref = $this->db->one(
            "SELECT id FROM referrals
             WHERE case_id = ? AND specialist_id = ? AND status = 'pending'",
            [(int) $case['id'], $uid]
        );
        return $ref !== null ? 'referee' : null;
    }

    public function inThread(string $rel, string $type): bool
    {
        return in_array($rel, self::MEMBERS[$type] ?? [], true);
    }

    /** The newest referral for a case, or null. */
    public function latestReferral(int $caseId): ?array
    {
        return $this->db->one(
            'SELECT * FROM referrals WHERE case_id = ? ORDER BY id DESC LIMIT 1',
            [$caseId]
        );
    }

    public function hasActiveReferral(int $caseId): bool
    {
        return $this->db->one(
            "SELECT id FROM referrals
             WHERE case_id = ? AND status IN ('awaiting_consent','pending','accepted')",
            [$caseId]
        ) !== null;
    }

    // =================================================================
    //  Threads and messages
    // =================================================================

    public function ensureThread(int $caseId, string $type): int
    {
        $this->db->run('INSERT IGNORE INTO threads (case_id, type) VALUES (?, ?)', [$caseId, $type]);
        return (int) $this->db->one(
            'SELECT id FROM threads WHERE case_id = ? AND type = ?',
            [$caseId, $type]
        )['id'];
    }

    public function threadId(int $caseId, string $type): ?int
    {
        $r = $this->db->one('SELECT id FROM threads WHERE case_id = ? AND type = ?', [$caseId, $type]);
        return $r === null ? null : (int) $r['id'];
    }

    public function addMessage(int $threadId, ?int $senderId, string $text, bool $system = false): int
    {
        $this->db->run(
            'INSERT INTO messages (thread_id, sender_id, is_system, body) VALUES (?, ?, ?, ?)',
            [$threadId, $senderId, $system ? 1 : 0, $this->crypto->seal($text)]
        );
        $id = $this->db->lastId();
        $this->db->run(
            'UPDATE cases c JOIN threads t ON t.case_id = c.id SET c.updated_at = NOW() WHERE t.id = ?',
            [$threadId]
        );
        return $id;
    }

    /** A translated status line. Stored as a key + parameters so each reader sees their own language. */
    public function system(int $caseId, string $thread, string $key, array $params = []): void
    {
        $tid = $this->ensureThread($caseId, $thread);
        $this->addMessage($tid, null, json_encode(['k' => $key, 'p' => $params], JSON_UNESCAPED_UNICODE), true);
    }

    /** One message row with its thread type and case id, or null. */
    public function messageRow(int $messageId): ?array
    {
        return $this->db->one(
            'SELECT m.*, t.type AS ttype, t.case_id
             FROM messages m JOIN threads t ON t.id = m.thread_id
             WHERE m.id = ?',
            [$messageId]
        );
    }

    /** May this user see this message (by membership, share or consented referral)? */
    public function canViewMessage(array $user, array $case, string $rel, array $msg): bool
    {
        if ($this->inThread($rel, $msg['ttype'])) {
            return true;
        }
        $uid = (int) $user['id'];
        $share = $this->db->one(
            'SELECT 1 FROM message_shares WHERE message_id = ? AND with_user_id = ?',
            [(int) $msg['id'], $uid]
        );
        if ($share !== null) {
            return true;
        }
        return $this->db->one(
            "SELECT 1 FROM referral_items i JOIN referrals r ON r.id = i.referral_id
             WHERE i.message_id = ? AND r.specialist_id = ? AND r.status IN ('pending','accepted')",
            [(int) $msg['id'], $uid]
        ) !== null;
    }

    // =================================================================
    //  Lists
    // =================================================================

    /** The signed-in user's own cases, shaped for their role. */
    public function listFor(array $user): array
    {
        $uid = (int) $user['id'];

        if ($user['role'] === 'patient') {
            $rows = $this->db->all(
                "SELECT c.*, EXISTS(SELECT 1 FROM referrals r
                    WHERE r.case_id = c.id AND r.status = 'awaiting_consent') AS awaiting
                 FROM cases c WHERE c.patient_id = ? ORDER BY c.updated_at DESC",
                [$uid]
            );
            return array_map(fn(array $c): array => $this->summary($c, 'patient', (bool) $c['awaiting']), $rows);
        }

        if ($user['doctor_type'] === 'general') {
            $rows = $this->db->all(
                "SELECT c.*, p.name AS pname FROM cases c JOIN users p ON p.id = c.patient_id
                 WHERE c.general_id = ? ORDER BY c.updated_at DESC",
                [$uid]
            );
            return array_map(fn(array $c): array => $this->summary($c, 'general', false), $rows);
        }

        $rows = $this->db->all(
            "SELECT c.*, p.name AS pname,
                    EXISTS(SELECT 1 FROM referrals r WHERE r.case_id = c.id
                           AND r.specialist_id = ? AND r.status = 'pending') AS pending
             FROM cases c JOIN users p ON p.id = c.patient_id
             WHERE c.specialist_id = ?
                OR c.id IN (SELECT case_id FROM referrals WHERE specialist_id = ? AND status = 'pending')
             ORDER BY c.updated_at DESC",
            [$uid, $uid, $uid]
        );
        return array_map(
            fn(array $c): array => $this->summary(
                $c,
                $c['specialist_id'] !== null && (int) $c['specialist_id'] === $uid ? 'specialist' : 'referee',
                (bool) $c['pending']
            ),
            $rows
        );
    }

    private function summary(array $c, string $rel, bool $flag): array
    {
        $out = [
            'id'        => (int) $c['id'],
            'code'      => $c['code'],
            'category'  => $c['category'],
            'urgency'   => $c['urgency'],
            'status'    => $c['status'],
            'ageBand'   => $c['age_band'],
            'sex'       => $c['sex'],
            'updatedAt' => strtotime((string) $c['updated_at']) * 1000,
            'rel'       => $rel,
            'flag'      => $flag, // patient: consent needed; specialist: referral waiting
        ];
        if ($rel === 'patient' || $rel === 'general') {
            $out['subject'] = $c['subject'];
        }
        if ($rel === 'general' || ($rel !== 'patient' && (int) $c['name_shared'] === 1)) {
            $out['patientName'] = $c['pname'] ?? null;
        }
        return $out;
    }

    /** Unclaimed cases: no name, no subject, no text. */
    public function pool(): array
    {
        $rows = $this->db->all(
            "SELECT id, code, category, urgency, lang, age_band, sex, created_at
             FROM cases WHERE status = 'new'
             ORDER BY FIELD(urgency, 'urgent', 'soon', 'routine'), created_at"
        );
        return array_map(static fn(array $c): array => [
            'id'        => (int) $c['id'],
            'code'      => $c['code'],
            'category'  => $c['category'],
            'urgency'   => $c['urgency'],
            'lang'      => $c['lang'],
            'ageBand'   => $c['age_band'],
            'sex'       => $c['sex'],
            'createdAt' => strtotime((string) $c['created_at']) * 1000,
        ], $rows);
    }

    // =================================================================
    //  Create
    // =================================================================

    public function newCode(): string
    {
        $alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
        for ($try = 0; $try < 10; $try++) {
            $code = '';
            for ($i = 0; $i < 8; $i++) {
                $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }
            if ($this->db->one('SELECT 1 FROM cases WHERE code = ?', [$code]) === null) {
                return $code;
            }
        }
        throw new RuntimeException('Could not make a case code');
    }

    // =================================================================
    //  The full view of one case, for one viewer
    // =================================================================

    public function view(int $caseId, array $user): array
    {
        $c = $this->row($caseId);
        $rel = $c === null ? null : $this->relation($user, $c);
        if ($c === null || $rel === null) {
            Response::fail('not_found', 404);
        }

        $uid  = (int) $user['id'];
        $ref  = $this->latestReferral($caseId);
        $open = $c['status'] !== 'closed';

        // People
        $names = [];
        foreach ([(int) $c['patient_id'], (int) ($c['general_id'] ?? 0), (int) ($c['specialist_id'] ?? 0), (int) ($ref['specialist_id'] ?? 0)] as $id) {
            if ($id > 0) {
                $u = $this->db->one('SELECT id, name, specialty FROM users WHERE id = ?', [$id]);
                if ($u !== null) {
                    $names[$id] = $u;
                }
            }
        }
        $patientVisible = in_array($rel, ['patient', 'general'], true) || (int) $c['name_shared'] === 1;
        $roleOf = static function (int $id) use ($c): string {
            if ($id === (int) $c['patient_id']) return 'patient';
            if ($c['general_id'] !== null && $id === (int) $c['general_id']) return 'general';
            return 'specialist';
        };

        // Messages this viewer may see
        $sharedIds = array_map('intval', $this->db->column(
            'SELECT s.message_id FROM message_shares s
             JOIN messages m ON m.id = s.message_id JOIN threads t ON t.id = m.thread_id
             WHERE s.with_user_id = ? AND t.case_id = ?',
            [$uid, $caseId]
        ));
        $referralIds = [];
        if ($ref !== null && (int) $ref['specialist_id'] === $uid && in_array($ref['status'], ['pending', 'accepted'], true)) {
            $referralIds = array_map('intval', $this->db->column(
                'SELECT message_id FROM referral_items WHERE referral_id = ?',
                [(int) $ref['id']]
            ));
        }
        $visibleExtra = array_flip(array_merge($sharedIds, $referralIds));

        $rows = $this->db->all(
            'SELECT m.id, m.sender_id, m.is_system, m.body, t.type AS ttype,
                    UNIX_TIMESTAMP(m.created_at) * 1000 AS ts,
                    a.id AS aid, a.seconds, a.transcript, a.transcript_status
             FROM messages m
             JOIN threads t ON t.id = m.thread_id
             LEFT JOIN audio_clips a ON a.message_id = m.id
             WHERE t.case_id = ?
             ORDER BY m.id',
            [$caseId]
        );

        $shares = [];
        foreach ($this->db->all(
            'SELECT s.message_id, s.with_user_id, s.shared_by FROM message_shares s
             JOIN messages m ON m.id = s.message_id JOIN threads t ON t.id = m.thread_id
             WHERE t.case_id = ?',
            [$caseId]
        ) as $s) {
            $shares[(int) $s['message_id']][] = [
                'role' => $roleOf((int) $s['with_user_id']),
                'mine' => (int) $s['shared_by'] === $uid,
            ];
        }

        $participants = ['patient'];
        if ($c['general_id'] !== null)    $participants[] = 'general';
        if ($c['specialist_id'] !== null) $participants[] = 'specialist';

        $threads = [];
        $shared  = [];
        foreach ($rows as $m) {
            $member = $this->inThread($rel, $m['ttype']);
            if (!$member && !isset($visibleExtra[(int) $m['id']])) {
                continue;
            }

            $out = [
                'id'     => (int) $m['id'],
                'thread' => $m['ttype'],
                'at'     => (int) $m['ts'],
                'system' => (bool) $m['is_system'],
                'from'   => $m['sender_id'] === null ? null : (int) $m['sender_id'],
                'role'   => 'system',
                'name'   => null,
                'text'   => '',
                'audio'  => null,
            ];

            $plain = $this->crypto->open($m['body']);
            if ($m['is_system']) {
                $d = json_decode($plain, true);
                $out['key']    = $d['k'] ?? '';
                $out['params'] = $d['p'] ?? new stdClass();
            } else {
                $sid = (int) $m['sender_id'];
                $out['role'] = $roleOf($sid);
                $out['name'] = ($out['role'] !== 'patient' || $patientVisible) ? ($names[$sid]['name'] ?? null) : null;
                $out['text'] = $plain;
                if ($m['aid'] !== null) {
                    $out['audio'] = [
                        'id'         => (int) $m['aid'],
                        'seconds'    => (int) $m['seconds'],
                        'status'     => $m['transcript_status'],
                        'transcript' => $m['transcript'] !== null ? $this->crypto->open($m['transcript']) : null,
                    ];
                }
                if ($member && $open) {
                    $sh = $shares[(int) $m['id']] ?? [];
                    $out['sharedWith']   = array_column($sh, 'role');
                    $out['sharedByMe']   = array_column(array_filter($sh, static fn(array $x): bool => $x['mine']), 'role');
                    $out['canShareWith'] = array_values(array_diff(
                        $participants,
                        self::MEMBERS[$m['ttype']],
                        $out['sharedWith']
                    ));
                }
            }

            if ($member) {
                $threads[$m['ttype']][] = $out;
            } else {
                $out['via'] = in_array((int) $m['id'], $referralIds, true) ? 'referral' : 'share';
                $shared[] = $out;
            }
        }

        // Threads the viewer belongs to, even when empty
        $myThreads = [];
        foreach (array_keys(self::MEMBERS) as $type) {
            if ($this->inThread($rel, $type) && $this->threadId($caseId, $type) !== null) {
                $myThreads[$type] = $threads[$type] ?? [];
            }
        }

        // Referral
        $referral = null;
        if ($ref !== null) {
            $mayRead = $rel === 'patient' || $rel === 'general'
                || (in_array($rel, ['specialist', 'referee'], true) && (int) $ref['specialist_id'] === $uid);
            if ($mayRead) {
                $specialistInfo = $names[(int) $ref['specialist_id']] ?? null;
                $referral = [
                    'id'          => (int) $ref['id'],
                    'status'      => $ref['status'],
                    'specialist'  => $specialistInfo['name'] ?? null,
                    'specialty'   => $specialistInfo['specialty'] ?? null,
                    'includeName' => (bool) $ref['include_name'],
                    'summary'     => $this->crypto->open($ref['summary']),
                    'itemIds'     => array_map('intval', $this->db->column(
                        'SELECT message_id FROM referral_items WHERE referral_id = ?',
                        [(int) $ref['id']]
                    )),
                ];
            }
        }

        $replyTo = [];
        if ($open) {
            foreach ($myThreads as $type => $_) {
                $replyTo[] = $type;
            }
        }

        return [
            'id'            => (int) $c['id'],
            'code'          => $c['code'],
            'rel'           => $rel,
            'status'        => $c['status'],
            'category'      => $c['category'],
            'urgency'       => $c['urgency'],
            'lang'          => $c['lang'],
            'ageBand'       => $c['age_band'],
            'sex'           => $c['sex'],
            'subject'       => in_array($rel, ['patient', 'general'], true) ? $c['subject'] : null,
            'patientName'   => $patientVisible ? ($names[(int) $c['patient_id']]['name'] ?? null) : null,
            'nameShared'    => (bool) $c['name_shared'],
            'generalName'   => $c['general_id'] !== null ? ($names[(int) $c['general_id']]['name'] ?? null) : null,
            'specialistName'=> $c['specialist_id'] !== null ? ($names[(int) $c['specialist_id']]['name'] ?? null) : null,
            'threads'       => $myThreads,
            'shared'        => $shared,
            'referral'      => $referral,
            'can'           => [
                'reply'    => $replyTo,
                'close'    => $open && $rel !== 'referee',
                'refer'    => $open && $rel === 'general' && $c['status'] === 'with_general' && !$this->hasActiveReferral($caseId),
                'consent'  => $open && $rel === 'patient' && $ref !== null && $ref['status'] === 'awaiting_consent',
                'respond'  => $open && $rel === 'referee',
                'withdraw' => $open && $rel === 'general' && $ref !== null && in_array($ref['status'], ['awaiting_consent', 'pending'], true),
                'shareName'=> $open && $rel === 'patient',
                'accessLog'=> $rel === 'patient',
            ],
        ];
    }
}
