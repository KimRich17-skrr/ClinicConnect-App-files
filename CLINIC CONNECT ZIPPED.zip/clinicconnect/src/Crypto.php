<?php
declare(strict_types=1);

/** Authenticated encryption (libsodium secretbox) for messages, audio and transcripts. */
final class Crypto
{
    private string $key;

    public function __construct(string $appKeyB64)
    {
        $raw = $appKeyB64 !== '' ? base64_decode($appKeyB64, true) : false;
        if ($raw === false || strlen($raw) !== SODIUM_CRYPTO_SECRETBOX_KEYBYTES) {
            throw new RuntimeException('APP_KEY missing or invalid');
        }
        $this->key = $raw;
    }

    public static function newKey(): string
    {
        return base64_encode(random_bytes(SODIUM_CRYPTO_SECRETBOX_KEYBYTES));
    }

    /** Returns raw bytes: nonce || ciphertext. */
    public function sealBytes(string $plain): string
    {
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return $nonce . sodium_crypto_secretbox($plain, $nonce, $this->key);
    }

    public function openBytes(string $blob): string
    {
        $n = SODIUM_CRYPTO_SECRETBOX_NONCEBYTES;
        if (strlen($blob) <= $n) {
            throw new RuntimeException('Bad ciphertext');
        }
        $plain = sodium_crypto_secretbox_open(substr($blob, $n), substr($blob, 0, $n), $this->key);
        if ($plain === false) {
            throw new RuntimeException('Decryption failed');
        }
        return $plain;
    }

    public function seal(string $plain): string
    {
        return base64_encode($this->sealBytes($plain));
    }

    public function open(string $b64): string
    {
        $raw = base64_decode($b64, true);
        if ($raw === false) {
            throw new RuntimeException('Bad ciphertext');
        }
        return $this->openBytes($raw);
    }
}
