<?php
declare(strict_types=1);

final class Auth
{
    public function __construct(
        private readonly Database $db,
        private readonly Mailer $mailer,
        private readonly string $baseUrl
    ) {}

    // ---------- Token helpers ----------

    public function issueToken(int $userId, string $type, int $seconds): string
    {
        $raw = bin2hex(random_bytes(32));

        $this->db->run('DELETE FROM tokens WHERE user_id = ? AND type = ?', [$userId, $type]);
        $this->db->run(
            'INSERT INTO tokens (user_id, type, token_hash, expires_at)
             VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND))',
            [$userId, $type, hash('sha256', $raw), $seconds]
        );

        return $raw;
    }

    public function findToken(string $raw, string $type): ?array
    {
        return $this->db->one(
            'SELECT * FROM tokens
             WHERE token_hash = ? AND type = ? AND expires_at > NOW()',
            [hash('sha256', $raw), $type]
        );
    }

    // ---------- User helpers ----------

    public function publicUser(array $u): array
    {
        return [
            'id'         => (int) $u['id'],
            'name'       => $u['name'],
            'email'      => $u['email'],
            'role'       => $u['role'],
            'doctorType' => $u['doctor_type'],
            'specialty'  => $u['specialty'],
            'lang'       => $u['lang'] ?? 'en',
        ];
    }

    /** Logged-in, verified user. Doctors must also be approved by an admin. */
    public function current(): ?array
    {
        if (empty($_SESSION['uid'])) {
            return null;
        }
        return $this->db->one(
            "SELECT * FROM users
             WHERE id = ? AND verified = 1 AND (role <> 'doctor' OR approved = 1)",
            [(int) $_SESSION['uid']]
        );
    }

    public function requireLogin(): array
    {
        $user = $this->current();
        if ($user === null) {
            Response::fail('login_required', 401);
        }
        return $user;
    }

    // ---------- Emails ----------

    public function sendVerify(array $user): void
    {
        $token = $this->issueToken((int) $user['id'], 'verify', 86400);
        $link  = "{$this->baseUrl}/verify.php?token={$token}";
        $lang  = (string) ($user['lang'] ?? 'en');

        $this->mailer->send(
            $user['email'],
            Lang::t($lang, 'mail.verify.subject'),
            Lang::t($lang, 'mail.verify.body', ['name' => $user['name'], 'link' => $link])
        );
    }

    public function sendReset(array $user): void
    {
        $token = $this->issueToken((int) $user['id'], 'reset', 3600);
        $link  = "{$this->baseUrl}/reset.php?token={$token}";
        $lang  = (string) ($user['lang'] ?? 'en');

        $this->mailer->send(
            $user['email'],
            Lang::t($lang, 'mail.reset.subject'),
            Lang::t($lang, 'mail.reset.body', ['name' => $user['name'], 'link' => $link])
        );
    }
}
