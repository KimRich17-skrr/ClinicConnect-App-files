<?php
declare(strict_types=1);

final class Mailer
{
    public function __construct(
        private readonly string $from,
        private readonly bool $enabled,
        private readonly bool $logToFile,
        private readonly string $logPath
    ) {}

    public function send(string $to, string $subject, string $body): void
    {
        if ($this->logToFile) {
            // Development only: this file holds live links. storage/ is blocked from the web.
            $line = sprintf("[%s] TO: %s\nSUBJECT: %s\n%s\n\n", date('c'), $to, $subject, $body);
            @file_put_contents($this->logPath, $line, FILE_APPEND);
        }
        if (!$this->enabled) {
            return;
        }
        $headers = "From: {$this->from}\r\nContent-Type: text/plain; charset=utf-8\r\n";
        @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers);
    }
}
