<?php
declare(strict_types=1);

/** Server-side strings (emails). The browser reads the same lang/*.json files. */
final class Lang
{
    private static array $cache = [];

    public static function t(string $lang, string $key, array $params = []): string
    {
        $lang = in_array($lang, Validator::LANGS, true) ? $lang : 'en';
        foreach ([$lang, 'en'] as $l) {
            if (!isset(self::$cache[$l])) {
                $file = __DIR__ . '/../lang/' . $l . '.json';
                $data = is_file($file) ? json_decode((string) file_get_contents($file), true) : [];
                self::$cache[$l] = is_array($data) ? $data : [];
            }
            if (isset(self::$cache[$l][$key])) {
                $s = (string) self::$cache[$l][$key];
                foreach ($params as $k => $v) {
                    $s = str_replace('{' . $k . '}', (string) $v, $s);
                }
                return $s;
            }
        }
        return $key;
    }
}
