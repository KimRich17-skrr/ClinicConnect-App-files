<?php
declare(strict_types=1);

/** Who did what to which case. Patients can read the log of their own case. */
final class Audit
{
    public function __construct(
        private readonly Database $db,
        private readonly string $ip
    ) {}

    public function log(?int $userId, ?int $caseId, string $action, string $detail = ''): void
    {
        $this->db->run(
            'INSERT INTO audit_log (user_id, case_id, action, detail, ip) VALUES (?, ?, ?, ?, ?)',
            [$userId, $caseId, substr($action, 0, 40), substr($detail, 0, 255), $this->ip]
        );
    }
}
