<?php
declare(strict_types=1);

/** Voice messages: validated, stored encrypted outside any public path, served only after an access check. */
final class Audio
{
    /** sniffed type => type we store and serve */
    private const ALLOWED = [
        'audio/webm'      => 'audio/webm',
        'video/webm'      => 'audio/webm',
        'audio/ogg'       => 'audio/ogg',
        'application/ogg' => 'audio/ogg',
        'audio/mp4'       => 'audio/mp4',
        'video/mp4'       => 'audio/mp4',
        'audio/x-m4a'     => 'audio/mp4',
        'audio/mpeg'      => 'audio/mpeg',
        'audio/wav'       => 'audio/wav',
        'audio/x-wav'     => 'audio/wav',
        'audio/aac'       => 'audio/aac',
    ];

    public function __construct(
        private readonly Database $db,
        private readonly Crypto $crypto,
        private readonly string $dir,
        private readonly array $cfg
    ) {}

    /**
     * Check an uploaded file. Returns null when there is none.
     * @return array{tmp:string,mime:string,bytes:int}|null
     */
    public function validate(?array $file): ?array
    {
        if ($file === null || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        $err = (int) $file['error'];
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
            Response::fail('audio_too_big', 413);
        }
        if ($err !== UPLOAD_ERR_OK || !is_uploaded_file((string) $file['tmp_name'])) {
            Response::fail('audio_invalid', 400);
        }
        $bytes = (int) $file['size'];
        if ($bytes < 200) {
            Response::fail('audio_invalid', 400);
        }
        if ($bytes > $this->cfg['max_bytes']) {
            Response::fail('audio_too_big', 413);
        }

        if (class_exists('finfo')) {
            $sniffed = (new finfo(FILEINFO_MIME_TYPE))->file((string) $file['tmp_name']) ?: '';
        } else {
            $sniffed = strtolower(trim(explode(';', (string) ($file['type'] ?? ''))[0]));
        }
        $mime = self::ALLOWED[$sniffed] ?? null;
        if ($mime === null) {
            Response::fail('audio_invalid', 415);
        }
        return ['tmp' => (string) $file['tmp_name'], 'mime' => $mime, 'bytes' => $bytes];
    }

    public function store(int $messageId, array $up, int $seconds): int
    {
        if (!is_dir($this->dir) && !@mkdir($this->dir, 0750, true) && !is_dir($this->dir)) {
            throw new RuntimeException('Audio folder missing');
        }
        $plain = (string) file_get_contents($up['tmp']);
        $name  = bin2hex(random_bytes(16)) . '.bin';
        if (file_put_contents($this->dir . '/' . $name, $this->crypto->sealBytes($plain)) === false) {
            throw new RuntimeException('Could not write audio');
        }
        $seconds = max(0, min($seconds, $this->cfg['max_seconds']));
        $this->db->run(
            'INSERT INTO audio_clips (message_id, file, mime, bytes, seconds) VALUES (?, ?, ?, ?, ?)',
            [$messageId, $name, $up['mime'], $up['bytes'], $seconds]
        );
        return $this->db->lastId();
    }

    /** @return array{mime:string,data:string,message_id:int}|null */
    public function read(int $clipId): ?array
    {
        $clip = $this->db->one('SELECT * FROM audio_clips WHERE id = ?', [$clipId]);
        if ($clip === null) {
            return null;
        }
        $path = $this->dir . '/' . basename($clip['file']);
        if (!is_file($path)) {
            return null;
        }
        return [
            'mime'       => $clip['mime'],
            'data'       => $this->crypto->openBytes((string) file_get_contents($path)),
            'message_id' => (int) $clip['message_id'],
        ];
    }

    public function saveTranscript(int $clipId, ?string $text): void
    {
        if ($text === null || trim($text) === '') {
            $this->db->run("UPDATE audio_clips SET transcript_status = 'failed' WHERE id = ?", [$clipId]);
            return;
        }
        $this->db->run(
            "UPDATE audio_clips SET transcript = ?, transcript_status = 'done' WHERE id = ?",
            [$this->crypto->seal(mb_substr(trim($text), 0, 5000)), $clipId]
        );
    }
}
