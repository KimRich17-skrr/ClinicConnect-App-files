<?php
declare(strict_types=1);

final class Validator
{
    public const CATEGORIES = [
        'general', 'fever', 'breathing', 'stomach', 'pain', 'skin',
        'pregnancy', 'child', 'mental', 'injury', 'chronic', 'other',
    ];
    public const URGENCY   = ['routine', 'soon', 'urgent'];
    public const AGE_BANDS = ['0-4', '5-12', '13-17', '18-39', '40-59', '60+'];
    public const SEX       = ['f', 'm', 'x'];
    public const LANGS     = ['en', 'lg'];

    public static function str(mixed $v, int $max = 2000): string
    {
        return is_scalar($v) ? mb_substr(trim((string) $v), 0, $max) : '';
    }

    public static function email(mixed $v): string
    {
        return strtolower(self::str($v, 190));
    }

    public static function passwordOk(mixed $v): bool
    {
        return is_string($v)
            && strlen($v) >= 8
            && preg_match('/[a-z]/i', $v) === 1
            && preg_match('/\d/', $v) === 1;
    }

    public static function oneOf(mixed $v, array $allowed, ?string $default = null): ?string
    {
        return is_string($v) && in_array($v, $allowed, true) ? $v : $default;
    }

    /** @return int[] */
    public static function ids(mixed $v, int $max = 30): array
    {
        if (!is_array($v)) {
            return [];
        }
        $out = [];
        foreach ($v as $x) {
            $i = (int) $x;
            if ($i > 0) {
                $out[$i] = $i;
            }
        }
        return array_slice(array_values($out), 0, $max);
    }
}
