<?php
declare(strict_types=1);

/** Simple fixed-window rate limiter stored in MySQL. */
final class Throttle
{
    public function __construct(private readonly Database $db) {}

    /** Count one hit. Returns true while the caller is still within the limit. */
    public function hit(string $key, int $max, int $seconds): bool
    {
        $key = substr($key, 0, 190);
        $this->db->run(
            'INSERT INTO rate_limits (k, hits, window_start) VALUES (?, 1, NOW())
             ON DUPLICATE KEY UPDATE
               hits = IF(window_start > NOW() - INTERVAL ? SECOND, hits + 1, 1),
               window_start = IF(window_start > NOW() - INTERVAL ? SECOND, window_start, NOW())',
            [$key, $seconds, $seconds]
        );
        $hits = (int) ($this->db->one('SELECT hits FROM rate_limits WHERE k = ?', [$key])['hits'] ?? 0);
        return $hits <= $max;
    }

    /** True if the key has already used up its allowance (does not count). */
    public function blocked(string $key, int $max, int $seconds): bool
    {
        $row = $this->db->one(
            'SELECT hits FROM rate_limits
             WHERE k = ? AND window_start > NOW() - INTERVAL ? SECOND',
            [substr($key, 0, 190), $seconds]
        );
        return $row !== null && (int) $row['hits'] >= $max;
    }

    public function clear(string $key): void
    {
        $this->db->run('DELETE FROM rate_limits WHERE k = ?', [substr($key, 0, 190)]);
    }
}
