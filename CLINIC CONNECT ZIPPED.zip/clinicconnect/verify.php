<?php require __DIR__ . '/src/layout.php'; cc_page_start('verify.title'); ?>
<main class="narrow">
  <div class="card">
    <h1 data-i18n="verify.title"></h1>
    <p id="t" data-i18n="verify.working"></p>
    <a class="btn" href="login.php" data-i18n="login.title"></a>
    <div id="out" class="msg" hidden role="status"></div>
  </div>
</main>
<?php cc_page_end(['verify']); ?>
