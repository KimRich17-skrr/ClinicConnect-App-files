<?php require __DIR__ . '/src/layout.php'; cc_page_start('nav.login', ['hero']); ?>
<main>
  <section class="card hero">
    <h1 data-i18n="home.title"></h1>
    <p data-i18n="home.lead"></p>
    <a class="btn" href="signup.php" data-i18n="home.cta"></a>
  </section>
  <section class="card">
    <h2 data-i18n="home.how"></h2>
    <ol>
      <li data-i18n="home.step1"></li>
      <li data-i18n="home.step2"></li>
      <li data-i18n="home.step3"></li>
      <li data-i18n="home.step4"></li>
    </ol>
    <p class="muted" data-i18n="home.warning"></p>
  </section>
</main>
<?php cc_page_end(['index']); ?>
